/* Default catalog and sample roster.
   Loaded only when the browser has no saved state (or after "Reset to sample").
   Edit freely, or manage everything from the "Course catalog" dialog in the app.
   Dates are ISO strings (YYYY-MM-DD). Day counts are calendar days. */

window.DEFAULT_DATA = {
  settings: {
    pauseDuringCourse: true   // line-item work stops while an individual is away at a resident course
  },

  roles: [
    {
      id: "wr1",
      name: "Work Role 1",
      short: "WR1",
      virtual: {
        name: "Virtual course",
        defaultDays: 75,
        cohortStarts: [
          "2026-08-03", "2026-09-08", "2026-10-05", "2026-11-02", "2026-12-07",
          "2027-01-04", "2027-02-01", "2027-03-01", "2027-04-05", "2027-05-03",
          "2027-06-07", "2027-07-06", "2027-08-02", "2027-09-07", "2027-10-04",
          "2027-11-01", "2027-12-06", "2028-01-03", "2028-02-07", "2028-03-06"
        ]
      },
      basicDays: 90,      // default calendar days a basic JQR takes
      seniorDays: 120,    // default calendar days a senior JQR takes
      tracks: [
        {
          id: "c1",
          name: "Course 1",
          blocks: ["Course 1A", "Course 1B", "Course 1C"],
          iterations: [
            { id: "c1-26a", blocks: [
              { start: "2026-10-13", end: "2026-10-30", location: "Fort Eisenhower, GA" },
              { start: "2026-11-16", end: "2026-12-04", location: "Fort Eisenhower, GA" },
              { start: "2027-01-11", end: "2027-01-29", location: "Fort Meade, MD" } ] },
            { id: "c1-27a", blocks: [
              { start: "2027-01-19", end: "2027-02-05", location: "Fort Eisenhower, GA" },
              { start: "2027-02-22", end: "2027-03-12", location: "Fort Eisenhower, GA" },
              { start: "2027-04-05", end: "2027-04-23", location: "Fort Meade, MD" } ] },
            { id: "c1-27b", blocks: [
              { start: "2027-04-12", end: "2027-04-30", location: "San Antonio, TX" },
              { start: "2027-05-17", end: "2027-06-04", location: "San Antonio, TX" },
              { start: "2027-06-28", end: "2027-07-16", location: "Fort Meade, MD" } ] },
            { id: "c1-27c", blocks: [
              { start: "2027-07-12", end: "2027-07-30", location: "Fort Eisenhower, GA" },
              { start: "2027-08-16", end: "2027-09-03", location: "Fort Eisenhower, GA" },
              { start: "2027-09-27", end: "2027-10-15", location: "Fort Meade, MD" } ] },
            { id: "c1-28a", blocks: [
              { start: "2027-10-18", end: "2027-11-05", location: "Fort Eisenhower, GA" },
              { start: "2027-11-29", end: "2027-12-17", location: "Fort Eisenhower, GA" },
              { start: "2028-01-18", end: "2028-02-04", location: "Fort Meade, MD" } ] },
            { id: "c1-28b", blocks: [
              { start: "2028-01-24", end: "2028-02-11", location: "San Antonio, TX" },
              { start: "2028-02-28", end: "2028-03-17", location: "San Antonio, TX" },
              { start: "2028-04-10", end: "2028-04-28", location: "Fort Meade, MD" } ] }
          ]
        },
        {
          id: "c2",
          name: "Course 2",
          blocks: ["Course 2 (main)", "Course 2 (follow-on)"],
          iterations: [
            { id: "c2-27a", blocks: [
              { start: "2026-11-02", end: "2026-12-18", location: "Pensacola, FL" },
              { start: "2027-01-19", end: "2027-01-29", location: "Fort Meade, MD" } ] },
            { id: "c2-27b", blocks: [
              { start: "2027-03-08", end: "2027-04-23", location: "Pensacola, FL" },
              { start: "2027-05-17", end: "2027-05-28", location: "Fort Meade, MD" } ] },
            { id: "c2-27c", blocks: [
              { start: "2027-07-06", end: "2027-08-20", location: "Pensacola, FL" },
              { start: "2027-09-13", end: "2027-09-24", location: "Fort Meade, MD" } ] },
            { id: "c2-28a", blocks: [
              { start: "2027-11-01", end: "2027-12-17", location: "Pensacola, FL" },
              { start: "2028-01-18", end: "2028-01-28", location: "Fort Meade, MD" } ] },
            { id: "c2-28b", blocks: [
              { start: "2028-03-06", end: "2028-04-21", location: "Pensacola, FL" },
              { start: "2028-05-15", end: "2028-05-26", location: "Fort Meade, MD" } ] }
          ]
        }
      ]
    },
    {
      id: "wr2",
      name: "Work Role 2",
      short: "WR2",
      virtual: {
        name: "Virtual course",
        defaultDays: 60,
        cohortStarts: [
          "2026-08-17", "2026-09-21", "2026-10-19", "2026-11-16", "2026-12-14",
          "2027-01-19", "2027-02-16", "2027-03-15", "2027-04-19", "2027-05-17",
          "2027-06-21", "2027-07-19", "2027-08-16", "2027-09-20", "2027-10-18",
          "2027-11-15", "2027-12-13", "2028-01-18", "2028-02-14", "2028-03-20"
        ]
      },
      basicDays: 75,
      seniorDays: 100,
      tracks: [
        {
          id: "c3",
          name: "Course 3",
          blocks: ["Course 3"],
          iterations: [
            { id: "c3-27a", blocks: [ { start: "2026-10-19", end: "2026-11-25", location: "Fort Eisenhower, GA" } ] },
            { id: "c3-27b", blocks: [ { start: "2027-01-11", end: "2027-02-19", location: "Fort Meade, MD" } ] },
            { id: "c3-27c", blocks: [ { start: "2027-03-29", end: "2027-05-07", location: "Fort Eisenhower, GA" } ] },
            { id: "c3-27d", blocks: [ { start: "2027-06-14", end: "2027-07-23", location: "Fort Meade, MD" } ] },
            { id: "c3-28a", blocks: [ { start: "2027-09-13", end: "2027-10-22", location: "Fort Eisenhower, GA" } ] },
            { id: "c3-28b", blocks: [ { start: "2027-12-06", end: "2028-01-21", location: "Fort Meade, MD" } ] },
            { id: "c3-28c", blocks: [ { start: "2028-03-13", end: "2028-04-21", location: "Fort Eisenhower, GA" } ] }
          ]
        }
      ]
    }
  ],

  /* Per individual:
       id              unique string
       name            rank + name as it should appear on the left
       roleId          work role id (must match a role above)
       trackId         "auto" = try every course option and pick the earliest FTQ, or a track id
       iterationId     "auto" = earliest achievable cohort, or a specific iteration id
       virtualStart    virtual course cohort start (ISO). Any date is allowed, not only listed cohorts.
       virtualEnd      predicted virtual completion (ISO), or null = start + role defaultDays - 1
       basicPct        basic JQR line items already complete, 0-100
       seniorPct       senior JQR line items already complete, 0-100
       basicDaysTotal  calendar days the basic JQR takes, or null for role basicDays
       seniorDaysTotal calendar days the senior JQR takes, or null for role seniorDays
     The projection is driven by the day counts above. basicPct / seniorPct are
     progress indicators only and do NOT change the projected FMQ / FTQ dates. */
  people: [
    { id: "p01", name: "SGT Alvarez",   roleId: "wr1", trackId: "auto", iterationId: "auto",   virtualStart: "2026-08-03", virtualEnd: "2026-09-25", basicPct: 35, seniorPct: 0,  basicDaysTotal: null, seniorDaysTotal: null },
    { id: "p02", name: "SPC Brennan",   roleId: "wr1", trackId: "auto", iterationId: "auto",   virtualStart: "2026-09-08", virtualEnd: null,         basicPct: 0,  seniorPct: 0,  basicDaysTotal: null, seniorDaysTotal: null },
    { id: "p03", name: "SSG Choi",      roleId: "wr1", trackId: "c2",   iterationId: "auto",   virtualStart: "2026-08-03", virtualEnd: "2026-09-18", basicPct: 50, seniorPct: 25, basicDaysTotal: null, seniorDaysTotal: null },
    { id: "p04", name: "SPC Dawson",    roleId: "wr1", trackId: "auto", iterationId: "auto",   virtualStart: "2026-10-05", virtualEnd: null,         basicPct: 0,  seniorPct: 0,  basicDaysTotal: null, seniorDaysTotal: null },
    { id: "p05", name: "PFC Espinoza",  roleId: "wr1", trackId: "auto", iterationId: "auto",   virtualStart: "2026-11-02", virtualEnd: null,         basicPct: 0,  seniorPct: 0,  basicDaysTotal: 110,  seniorDaysTotal: null },
    { id: "p06", name: "SGT Fischer",   roleId: "wr1", trackId: "c1",   iterationId: "c1-27b", virtualStart: "2026-09-08", virtualEnd: null,         basicPct: 0,  seniorPct: 0,  basicDaysTotal: null, seniorDaysTotal: null },
    { id: "p07", name: "SPC Gaines",    roleId: "wr2", trackId: "auto", iterationId: "auto",   virtualStart: "2026-08-17", virtualEnd: "2026-10-02", basicPct: 30, seniorPct: 0,  basicDaysTotal: null, seniorDaysTotal: null },
    { id: "p08", name: "SSG Hartley",   roleId: "wr2", trackId: "auto", iterationId: "auto",   virtualStart: "2026-09-21", virtualEnd: null,         basicPct: 0,  seniorPct: 20, basicDaysTotal: null, seniorDaysTotal: null },
    { id: "p09", name: "SPC Ibarra",    roleId: "wr2", trackId: "auto", iterationId: "auto",   virtualStart: "2026-10-19", virtualEnd: null,         basicPct: 0,  seniorPct: 0,  basicDaysTotal: null, seniorDaysTotal: null },
    { id: "p10", name: "PFC Jensen",    roleId: "wr2", trackId: "auto", iterationId: "auto",   virtualStart: "2026-11-16", virtualEnd: null,         basicPct: 0,  seniorPct: 0,  basicDaysTotal: 90,   seniorDaysTotal: null },
    { id: "p11", name: "SGT Kowalski",  roleId: "wr2", trackId: "auto", iterationId: "c3-27c", virtualStart: "2026-09-21", virtualEnd: "2026-12-04", basicPct: 10, seniorPct: 0,  basicDaysTotal: null, seniorDaysTotal: null },
    { id: "p12", name: "SPC Lindqvist", roleId: "wr1", trackId: "auto", iterationId: "auto",   virtualStart: "2026-12-07", virtualEnd: null,         basicPct: 0,  seniorPct: 0,  basicDaysTotal: null, seniorDaysTotal: null }
  ]
};
