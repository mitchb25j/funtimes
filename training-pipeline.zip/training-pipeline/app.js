/* =============================================================================
   Training Pipeline Projection — app.js
   Vanilla JavaScript, no libraries. Runs from file:// or any static host.

   HOW THE FILE IS ORGANISED
     1.  Constants and date helpers        pure functions, no DOM
     2.  Fiscal-quarter helpers           FY starts 1 Oct
     3.  State: load / save / migrate     localStorage + data file + DEFAULT_DATA
     4.  Scheduling engine                schedule(person) -> plan object
     5.  Rendering: summary table         per-quarter FTQ counts
     5b. Readiness tiles + snapshots      KPIs and month-over-month deltas
     6.  Rendering: timeline grid         one row per individual (density-aware)
     7.  Rendering: row editor            inline form under a clicked row
     8.  Rendering: course catalog dialog edit roles / cohorts / courses
     8b. Durable file persistence        optional File System Access binding
     9.  Import / export
     10. Event wiring and first render

   KEY CONCEPTS (so a new maintainer can orient fast)
     - FMQ = basic qualified (virtual course + basic JQR done).
       FTQ = fully trained (FMQ + senior JQR + senior resident course done).
     - A "plan" is the fully computed schedule for one person (schedule()); plans[]
       holds one per person and every panel is drawn from it.
     - JQR % complete is display only. Projected dates come from the JQR *duration*
       in days; changing the % never moves a date (see schedule()).
     - Row density (wide/compact/dense) is pure CSS: see the geometry variables in
       styles.css. app.js only toggles a body class.
     - Persistence has two layers: localStorage (always on) and an optional bound
       JSON data file (section 8b). Monthly snapshots (section 5b) ride along in the
       saved state so the deltas survive across sessions.

   DEBUGGING TIPS
     - Open the browser console. `window.__pipeline` exposes { state, plans, schedule,
       renderAll } so you can inspect the computed plan for anyone:
         __pipeline.plans.find(p => p.person.name.includes('Choi'))
     - Every render goes through renderAll(). If something looks stale, the usual
       cause is a handler that mutated state without calling renderAll().
     - Row geometry (bar heights, caption and flag positions) is all in styles.css
       under "Timeline"; app.js only sets left/width. Change --row-h to resize rows.
     - Dates are ISO strings ('2026-10-05') everywhere in state and plans. They are
       compared with plain string comparison, which is correct for ISO format.
     - The saved state lives under localStorage key STORE_KEY. Delete it (or use
       "Reset to sample") if a bad import leaves the page blank.
   ============================================================================= */
(function () {
  'use strict';

  /* ---------------------------------------------------------------------------
     1. Constants and date helpers
     --------------------------------------------------------------------------- */
  const STORE_KEY = 'trainingPipeline.v2';   // bump the suffix if the state shape changes
  const MAX_PEOPLE = 100;
  const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

  // All dates are ISO 'YYYY-MM-DD' strings. We parse them as UTC midnight so that
  // the user's local time zone can never shift a date by one day.
  function parse(s) { return new Date(s + 'T00:00:00Z'); }
  function iso(d) { return d.toISOString().slice(0, 10); }
  function addDays(s, n) { const d = parse(s); d.setUTCDate(d.getUTCDate() + n); return iso(d); }
  function diff(a, b) { return Math.round((parse(b) - parse(a)) / 86400000); } // whole days from a to b
  function maxIso(a, b) { return a > b ? a : b; }
  function minIso(a, b) { return a < b ? a : b; }
  function clamp(n, lo, hi) { return Math.min(hi, Math.max(lo, n)); }

  // '05 Oct 26' — compact military-style date for table cells and bar labels.
  function fmt(s) {
    if (!s) return '—';
    const d = parse(s);
    return String(d.getUTCDate()).padStart(2, '0') + ' ' + MONTHS[d.getUTCMonth()] + ' ' + String(d.getUTCFullYear()).slice(2);
  }
  // '05 Oct 2026' — used in tooltips and the editor outcome line.
  function fmtLong(s) {
    if (!s) return '—';
    const d = parse(s);
    return String(d.getUTCDate()).padStart(2, '0') + ' ' + MONTHS[d.getUTCMonth()] + ' ' + d.getUTCFullYear();
  }

  // Today's date, taken from the machine clock, as an ISO string.
  // To test the page "as of" another date, replace this with a literal, e.g. '2027-01-15'.
  const TODAY = (function () {
    const d = new Date();
    return iso(new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate())));
  })();

  /* ---------------------------------------------------------------------------
     2. Fiscal-quarter helpers
     FY starts 1 Oct. Q1 Oct–Dec, Q2 Jan–Mar, Q3 Apr–Jun, Q4 Jul–Sep.
     A quarter is represented as { fy: 2027, q: 2 }.
     --------------------------------------------------------------------------- */
  function fq(s) {
    const d = parse(s), m = d.getUTCMonth(), y = d.getUTCFullYear();
    if (m >= 9) return { fy: y + 1, q: 1 };   // Oct–Dec belong to next FY
    if (m <= 2) return { fy: y, q: 2 };
    if (m <= 5) return { fy: y, q: 3 };
    return { fy: y, q: 4 };
  }
  function fqStart(fy, q) { return [null, (fy - 1) + '-10-01', fy + '-01-01', fy + '-04-01', fy + '-07-01'][q]; }
  function fqEnd(fy, q)   { return [null, (fy - 1) + '-12-31', fy + '-03-31', fy + '-06-30', fy + '-09-30'][q]; }
  function fqNext(f) { return f.q === 4 ? { fy: f.fy + 1, q: 1 } : { fy: f.fy, q: f.q + 1 }; }
  function fqLabel(f) { return 'FY' + String(f.fy).slice(2) + ' Q' + f.q; }
  function fqKey(f) { return f.fy + '-' + f.q; }   // string key for equality checks

  /* ---------------------------------------------------------------------------
     3. State
     state = { settings, roles[], people[] }  — see data.js for the shape.
     ui    = transient view state that is NOT persisted.
     --------------------------------------------------------------------------- */
  let state = load();
  const ui = {
    openId: null,        // id of the person whose editor is expanded, or null
    sort: 'ftq',         // default: soonest FTQ at the top
    filter: 'all',       // role id or 'all'
    zoom: '4',           // px per day ('4' ≈ 120px per month), or 'fit' to stretch to the window width
    density: 'standard', // row size: 'wide' | 'standard' | 'compact' | 'dense' (drives CSS geometry)
    present: false,      // briefing mode: hides editing controls, rows are not clickable
    export: false,       // one-page export overview (whole roster on a single letter sheet)
    catalogOpen: false
  };

  function clone(o) { return JSON.parse(JSON.stringify(o)); }

  function load() {
    try {
      const raw = localStorage.getItem(STORE_KEY);
      if (raw) {
        const s = JSON.parse(raw);
        if (s && Array.isArray(s.roles) && Array.isArray(s.people)) return migrate(s);
      }
    } catch (e) { console.warn('Could not read saved state, using defaults', e); }
    return migrate(clone(window.DEFAULT_DATA));
  }

  // Fill in any missing fields so older exports and hand-edited data.js files still work.
  function migrate(s) {
    s.settings = s.settings || {};
    if (s.settings.pauseDuringCourse == null) s.settings.pauseDuringCourse = true;
    if (typeof s.notes !== 'string') s.notes = s.notes ? String(s.notes) : '';   // briefing notes (one bullet per line)
    s.snapshots = (s.snapshots && typeof s.snapshots === 'object') ? s.snapshots : {};  // { 'YYYY-MM': {metrics} }
    s.roles.forEach(r => {
      r.virtual = r.virtual || { name: 'Virtual course', defaultDays: 60, cohortStarts: [] };
      r.virtual.cohortStarts = (r.virtual.cohortStarts || []).slice().sort();
      r.tracks = r.tracks || [];
      r.tracks.forEach(t => { t.blocks = t.blocks || ['Block 1']; t.iterations = t.iterations || []; });
    });
    s.people.forEach(p => {
      // v1 files stored "days remaining"; convert to the % model (0% complete, custom total).
      if (p.basicPct == null) { p.basicPct = 0; if (p.basicDays != null) p.basicDaysTotal = p.basicDays; }
      if (p.seniorPct == null) { p.seniorPct = 0; if (p.seniorDays != null) p.seniorDaysTotal = p.seniorDays; }
      delete p.basicDays; delete p.seniorDays;
      if (p.basicDaysTotal === undefined) p.basicDaysTotal = null;
      if (p.seniorDaysTotal === undefined) p.seniorDaysTotal = null;
      p.trackId = p.trackId || 'auto';
      p.iterationId = p.iterationId || 'auto';
    });
    return s;
  }

  function save() {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(state)); }
    catch (e) { console.warn('Could not save state', e); }
    scheduleFileWrite();   // also persist to the bound data file, if one is connected (no-op otherwise)
  }
  function uid(prefix) { return prefix + Math.random().toString(36).slice(2, 8); }
  function role(id) { return state.roles.find(r => r.id === id) || state.roles[0]; }

  /* ---------------------------------------------------------------------------
     4. Scheduling engine
     Input:  one person + the catalog (via state)
     Output: a "plan" object with every computed date, the chosen course/cohort,
             the bar segments to draw, and a list of warning strings.

     Sequence for one individual:
       virtual course  [vStart .. vEnd]
       basic JQR       starts max(vEnd + 1, today), runs the basic JQR duration (working days)
       senior JQR      starts the day after basic ends, runs the senior JQR duration
       resident course blocks (from the chosen cohort) sit wherever the catalog puts them
       FMQ = last basic JQR day
       FTQ = later of (last course block end, last senior JQR day)
     "Working day" = any calendar day, except days inside a course block when
     settings.pauseDuringCourse is on.
     --------------------------------------------------------------------------- */

  // First listed cohort start on or after `from`; falls back to the last one, then to `from`.
  function nextCohort(r, from) {
    const list = (r.virtual.cohortStarts || []).slice().sort();
    return list.find(d => d >= from) || list[list.length - 1] || from;
  }

  function inBlocks(day, blocks) {
    for (const b of blocks) if (day >= b.start && day <= b.end) return true;
    return false;
  }

  // Walk forward from `start` one day at a time until `days` working days are used up.
  // Returns { segs: [{start,end}, ...], end } where segs are the contiguous stretches of
  // work (split around course blocks) that the timeline draws as bars.
  // If days <= 0, `end` is the day before `start` so the next phase starts at `start`.
  function consume(start, days, blocks, pause) {
    const segs = [];
    if (days <= 0) return { segs, end: addDays(start, -1) };
    let cur = start, left = days, open = null, guard = 0;
    while (left > 0 && guard++ < 5000) {           // guard: never loop forever on bad input
      if (pause && inBlocks(cur, blocks)) {
        if (open) { segs.push(open); open = null; } // course day: close the current bar
      } else {
        if (!open) open = { start: cur, end: cur }; else open.end = cur;
        left--;
      }
      cur = addDays(cur, 1);
    }
    if (open) segs.push(open);
    return { segs, end: segs.length ? segs[segs.length - 1].end : addDays(start, -1) };
  }

  // Lay out basic JQR, senior JQR, and compute FMQ / FTQ for a given set of course blocks.
  function buildPlan(liStart, basicDays, seniorDays, blocks, pause) {
    const b = consume(liStart, basicDays, blocks, pause);
    const s = consume(addDays(b.end, 1), seniorDays, blocks, pause);
    const courseEnd = blocks.length ? blocks[blocks.length - 1].end : null;
    return {
      basicSegs: b.segs, fmq: b.end,
      seniorSegs: s.segs, seniorEnd: s.end,
      courseEnd,
      ftq: courseEnd ? maxIso(courseEnd, s.end) : null   // null = cannot reach FTQ
    };
  }

  function schedule(p) {
    const r = role(p.roleId);
    const warnings = [];

    // --- virtual course -------------------------------------------------------
    const vStart = p.virtualStart || nextCohort(r, TODAY);
    const vEnd = p.virtualEnd || addDays(vStart, Math.max(1, r.virtual.defaultDays) - 1);
    if (vEnd < vStart) warnings.push('Virtual course end is before its start.');

    // --- JQR work volume ------------------------------------------------------
    const basicTotal = p.basicDaysTotal == null ? r.basicDays : p.basicDaysTotal;
    const seniorTotal = p.seniorDaysTotal == null ? r.seniorDays : p.seniorDaysTotal;
    // JQR % complete is a progress indicator only; it does NOT change the projection.
    // Projected dates are driven solely by the JQR duration in calendar days (edit the
    // duration to shorten or lengthen the estimate).
    const basicDays = basicTotal;
    const seniorDays = seniorTotal;
    const liStart = maxIso(addDays(vEnd, 1), TODAY);   // work already done is not re-drawn
    const pause = !!state.settings.pauseDuringCourse;

    // --- candidate course cohorts --------------------------------------------
    // Manual selections are always honoured (and warned about if they look wrong).
    // Auto selection only considers cohorts that start after the virtual course and after today.
    const tracks = p.trackId === 'auto' ? r.tracks : r.tracks.filter(t => t.id === p.trackId);
    if (p.trackId !== 'auto' && !tracks.length) warnings.push('Selected course no longer exists; showing earliest available.');
    const manual = p.iterationId !== 'auto';
    const candidates = [];
    for (const t of (tracks.length ? tracks : r.tracks)) {
      for (const it of t.iterations) {
        if (manual && it.id !== p.iterationId) continue;
        const blocks = it.blocks.slice().sort((a, b) => a.start.localeCompare(b.start));
        if (!blocks.length) continue;
        if (!manual && blocks[0].start <= vEnd) continue;
        if (!manual && blocks[0].start < TODAY) continue;
        candidates.push({ track: t, iteration: it, blocks, plan: buildPlan(liStart, basicDays, seniorDays, blocks, pause) });
      }
    }
    if (manual && !candidates.length) warnings.push('Selected cohort no longer exists.');

    // Earliest FTQ wins; ties broken by earliest course start.
    candidates.sort((a, b) => a.plan.ftq.localeCompare(b.plan.ftq) || a.blocks[0].start.localeCompare(b.blocks[0].start));
    const pick = candidates[0] || null;

    let plan;
    if (pick) {
      plan = pick.plan;
      if (pick.blocks[0].start <= vEnd) warnings.push('Course starts before the virtual course is complete.');
      if (pick.blocks[0].start < TODAY) warnings.push('Course start date is in the past.');
    } else {
      plan = buildPlan(liStart, basicDays, seniorDays, [], pause);
      warnings.push('No course cohort is available after the virtual course ends.');
    }

    return {
      person: p, role: r,
      vStart, vEnd, liStart,
      basicTotal, seniorTotal, basicDays, seniorDays,
      track: pick ? pick.track : null,
      iteration: pick ? pick.iteration : null,
      blocks: pick ? pick.blocks : [],
      basicSegs: plan.basicSegs, fmq: plan.fmq,
      seniorSegs: plan.seniorSegs, seniorEnd: plan.seniorEnd,
      courseEnd: plan.courseEnd, ftq: plan.ftq,
      warnings
    };
  }

  /* ---------------------------------------------------------------------------
     Small DOM helper. el('div', { class: 'x', onclick: fn, text: 'hi' }, [children])
     Attribute keys: class, style, text, html, on<event>, anything else -> setAttribute.
     --------------------------------------------------------------------------- */
  const $ = (sel) => document.querySelector(sel);
  function el(tag, attrs, children) {
    const n = document.createElement(tag);
    if (attrs) for (const k in attrs) {
      const v = attrs[k];
      if (k === 'class') n.className = v;
      else if (k === 'style') n.style.cssText = v;
      else if (k === 'text') n.textContent = v;
      else if (k === 'html') n.innerHTML = v;
      else if (k.startsWith('on')) n.addEventListener(k.slice(2), v);
      else if (v != null && v !== false) n.setAttribute(k, v === true ? '' : v);
    }
    if (children) for (const c of [].concat(children)) {
      if (c == null || c === false) continue;
      n.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    }
    return n;
  }
  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  /* ---------------------------------------------------------------------------
     Master render. Recomputes every plan, then redraws all panels.
     Focus is restored by data-k attribute so typing into an input and tabbing
     away does not lose the cursor after the re-render.
     --------------------------------------------------------------------------- */
  let plans = [];   // one plan per person, same order as state.people

  function renderAll() {
    const focusKey = document.activeElement && document.activeElement.dataset ? document.activeElement.dataset.k : null;
    plans = state.people.map(schedule);
    renderFilter();
    renderSummary();
    renderKpis();
    renderNotes();
    renderLegend();
    renderTimeline();
    if (ui.export) { renderExport(); fitExportPage(); }   // the one-page bar chart
    if (ui.catalogOpen) renderCatalog();
    if (focusKey) { const n = document.querySelector('[data-k="' + focusKey + '"]'); if (n) n.focus(); }
    save();
  }

  // Scale the export sheet so it fits one US Letter LANDSCAPE page. The sheet is built
  // at a fixed design size with a roughly landscape aspect, so this mostly fills the page.
  function fitExportPage() {
    const sheet = $('#export-sheet');
    if (!sheet) return;
    const PAGE_W = 984, PAGE_H = 735;        // landscape Letter content @96dpi, small safety margin
    sheet.style.zoom = '1';
    const w = sheet.scrollWidth, h = sheet.scrollHeight;
    if (!w || !h) return;
    sheet.style.zoom = String(Math.min(PAGE_W / w, PAGE_H / h, 1));
  }

  function renderFilter() {
    const sel = $('#filter-role');
    sel.innerHTML = '';
    sel.appendChild(el('option', { value: 'all', text: 'All work roles' }));
    for (const r of state.roles) sel.appendChild(el('option', { value: r.id, text: r.name }));
    sel.value = state.roles.some(r => r.id === ui.filter) ? ui.filter : 'all';
  }

  // Plans after the role filter and sort are applied. Used by the timeline only.
  function visiblePlans() {
    let list = plans.filter(pl => ui.filter === 'all' || pl.person.roleId === ui.filter);
    const far = '9999-12-31';   // unreachable FTQ sorts last
    const cmp = {
      added: null,
      ftq:  (a, b) => (a.ftq || far).localeCompare(b.ftq || far) || a.fmq.localeCompare(b.fmq),
      fmq:  (a, b) => a.fmq.localeCompare(b.fmq),
      name: (a, b) => a.person.name.localeCompare(b.person.name),
      role: (a, b) => a.role.name.localeCompare(b.role.name) || (a.ftq || far).localeCompare(b.ftq || far)
    }[ui.sort];
    return cmp ? list.slice().sort(cmp) : list;
  }

  /* ---------------------------------------------------------------------------
     5. Summary table
     Columns: "Already" (before today), one per fiscal quarter from the current
     quarter to the last projected FTQ (max 12), then "Total".
     Cells: number of individuals whose FMQ / FTQ falls INSIDE that quarter.
     --------------------------------------------------------------------------- */
  function quarterRange() {
    let f = fq(TODAY), last = fq(TODAY);
    for (const pl of plans) {
      const d = pl.ftq || pl.fmq;
      const q = fq(d);
      if (q.fy > last.fy || (q.fy === last.fy && q.q > last.q)) last = q;
    }
    const qs = [];
    for (let i = 0; i < 12; i++) {
      qs.push(f);
      if (fqKey(f) === fqKey(last)) break;
      f = fqNext(f);
    }
    return qs;
  }

  // Count plans whose `field` date falls within [qStart, qEnd].
  function countIn(group, field, qStart, qEnd) {
    return group.filter(pl => pl[field] && pl[field] >= qStart && pl[field] <= qEnd).length;
  }

  function renderSummary() {
    const box = $('#summary');
    box.innerHTML = '';
    if (!state.people.length) {
      box.appendChild(el('div', { class: 'empty', text: 'No individuals yet. Add one to see projections.' }));
      return;
    }
    const qs = quarterRange();
    const table = el('table', { class: 'summary-table' });

    // ---- header: FY spanning row + quarter row ----
    const thead = el('thead');
    const fyRow = el('tr', { class: 'fy-row' });
    fyRow.appendChild(el('th', { class: 'label' }));
    fyRow.appendChild(el('th'));                        // Already
    let i = 0;
    while (i < qs.length) {
      let j = i; while (j < qs.length && qs[j].fy === qs[i].fy) j++;
      fyRow.appendChild(el('th', { class: 'fy', colspan: j - i, text: 'FY' + qs[i].fy }));
      i = j;
    }
    fyRow.appendChild(el('th'));                        // Total
    thead.appendChild(fyRow);

    const qRow = el('tr');
    qRow.appendChild(el('th', { class: 'label', text: 'Fully trained (FTQ) in quarter' }));
    qRow.appendChild(el('th', { class: 'q first', text: 'Already' }));
    qs.forEach((q, idx) => qRow.appendChild(el('th', {
      class: 'q' + (idx === 0 || qs[idx - 1].fy !== q.fy ? ' first' : '') + (idx === 0 ? ' cur' : ''),
      text: 'Q' + q.q, title: fmtLong(fqStart(q.fy, q.q)) + ' – ' + fmtLong(fqEnd(q.fy, q.q))
    })));
    qRow.appendChild(el('th', { class: 'q first', text: 'Total' }));
    thead.appendChild(qRow);
    table.appendChild(thead);

    // ---- body: two rows per role, then totals ----
    const tbody = el('tbody');
    const tot = { ftq: qs.map(() => 0), ftqNow: 0, n: 0 };
    const unscheduled = [];

    for (const r of state.roles) {
      const group = plans.filter(pl => pl.person.roleId === r.id);
      if (!group.length) continue;
      group.forEach(pl => { if (!pl.ftq) unscheduled.push(pl); });

      const ftqNow = group.filter(pl => pl.ftq && pl.ftq < TODAY).length;
      // For the current quarter only count from today forward, so "Already" + quarters = total.
      const ftqQ = qs.map((q, idx) => countIn(group, 'ftq', idx === 0 ? TODAY : fqStart(q.fy, q.q), fqEnd(q.fy, q.q)));

      tbody.appendChild(numRow(r.name, 'ftq', ftqNow, ftqQ, qs, group.length - group.filter(pl => !pl.ftq).length, group.length));

      tot.n += group.length; tot.ftqNow += ftqNow;
      ftqQ.forEach((v, k) => tot.ftq[k] += v);
    }
    if (state.roles.filter(r => plans.some(pl => pl.person.roleId === r.id)).length > 1) {
      const t2 = numRow('All roles', 'ftq', tot.ftqNow, tot.ftq, qs, tot.n - unscheduled.length, tot.n); t2.classList.add('total');
      tbody.appendChild(t2);
    }
    table.appendChild(tbody);
    box.appendChild(table);

    const note = el('div', { class: 'summary-note' });
    note.appendChild(document.createTextNode(tot.n + ' of ' + MAX_PEOPLE + ' tracked. Hover a quarter for its dates.'));
    if (unscheduled.length) note.appendChild(el('span', { class: 'warn', text: ' ' + unscheduled.length + ' cannot reach FTQ with the current catalog: ' + unscheduled.map(pl => pl.person.name).join(', ') + '.' }));
    box.appendChild(note);
  }

  /* ---------------------------------------------------------------------------
     5b. Readiness tiles + monthly snapshots
     Metrics are captured once per month (stored in state.snapshots, so they travel
     with the data file). Deltas compare this month's live figures to the most
     recent earlier month on record — which is why durable persistence matters.
     --------------------------------------------------------------------------- */
  function monthKey(s) { return s.slice(0, 7); }
  function curMonthKey() { return monthKey(TODAY); }
  function monthName(key) { const p = key.split('-'); return MONTHS[+p[1] - 1] + " '" + p[0].slice(2); }

  function computeMetrics() {
    const fyEnd = fqEnd(fq(TODAY).fy, 4);
    const ftqReached = plans.filter(pl => pl.ftq && pl.ftq <= TODAY).length;         // fully trained as of today
    const projFtqByFy = plans.filter(pl => pl.ftq && pl.ftq <= fyEnd).length;        // projected FTQ by end of current FY
    const basics = plans.map(pl => pl.basicDays).filter(n => typeof n === 'number');
    const avgBasicDays = basics.length ? Math.round(basics.reduce((a, b) => a + b, 0) / basics.length) : 0;
    return { n: plans.length, ftqReached, projFtqByFy, avgBasicDays };
  }
  // Most recent stored snapshot from a month earlier than the current one.
  function prevMonthSnapshot() {
    const ck = curMonthKey();
    const keys = Object.keys(state.snapshots || {}).filter(k => k < ck).sort();
    return keys.length ? state.snapshots[keys[keys.length - 1]] : null;
  }
  // Record / refresh the current month's snapshot. It freezes automatically once the
  // month rolls over, because its key is no longer the current month.
  function updateSnapshot(m) {
    state.snapshots = state.snapshots || {};
    state.snapshots[curMonthKey()] = Object.assign({ capturedAt: TODAY }, m);
  }

  // Small signed change chip under a tile. goodWhen tells it which direction is green.
  function deltaBadge(delta, goodWhen, unit, prev) {
    if (delta == null) return el('div', { class: 'delta none', text: 'baseline set this month' });
    const zero = delta === 0;
    const good = zero ? null : (goodWhen === 'down' ? delta < 0 : delta > 0);
    const arrow = zero ? '±' : (delta > 0 ? '▲' : '▼');
    const vs = prev && prev.capturedAt ? ' vs ' + monthName(monthKey(prev.capturedAt)) : '';
    return el('div', { class: 'delta ' + (zero ? 'flat' : good ? 'good' : 'bad'), text: arrow + ' ' + Math.abs(delta) + (unit || '') + vs });
  }

  function renderKpis() {
    const box = $('#kpis');
    if (!box) return;
    box.innerHTML = '';
    if (!state.people.length) return;

    const m = computeMetrics();
    const prev = prevMonthSnapshot();
    updateSnapshot(m);   // persists with state (and the data file)
    const fyTag = 'FY' + String(fq(TODAY).fy).slice(2);

    const tile = (value, label, opts) => {
      opts = opts || {};
      const t = el('div', { class: 'kpi' });
      const v = el('div', { class: 'v' }, [String(value)]);
      if (opts.of != null) v.appendChild(el('span', { class: 'of', text: ' of ' + opts.of }));
      t.appendChild(v);
      t.appendChild(el('div', { class: 'l', text: label }));
      if (opts.sub) t.appendChild(el('div', { class: 'sub', text: opts.sub }));
      if (opts.delta !== undefined) t.appendChild(deltaBadge(opts.delta, opts.goodWhen, opts.unit, prev));
      return t;
    };

    box.appendChild(tile(m.n, 'Individuals tracked', { sub: 'registered for the virtual course or further along' }));
    box.appendChild(tile(m.projFtqByFy, 'Projected FTQ by end ' + fyTag, { of: m.n, sub: 'on the current plan' }));
    box.appendChild(tile(m.ftqReached, 'Fully trained (FTQ) to date', { delta: prev ? m.ftqReached - prev.ftqReached : null, goodWhen: 'up' }));
    box.appendChild(tile(m.avgBasicDays, 'Avg Basic JQR (days)', { delta: prev ? m.avgBasicDays - prev.avgBasicDays : null, goodWhen: 'down', unit: 'd' }));
  }

  // Briefing notes: free-text, one bullet per line. Editable textarea in normal mode,
  // rendered as a clean bullet list in briefing / print.
  function renderNotes() {
    const box = $('#notes');
    if (!box) return;
    box.innerHTML = '';
    box.appendChild(el('div', { class: 'notes-head', text: 'Notes' }));
    const bullets = (state.notes || '').split('\n').map(s => s.trim()).filter(Boolean);
    const readOnly = ui.present || ui.export;   // briefing and export both hide the editable box
    if (bullets.length) {
      const ul = el('ul', { class: 'notes-list' });
      bullets.forEach(b => ul.appendChild(el('li', { text: b })));
      box.appendChild(ul);
    } else if (readOnly) {
      box.appendChild(el('div', { class: 'notes-empty', text: '— none —' }));
    }
    if (!readOnly) {
      box.appendChild(el('textarea', {
        class: 'notes-input', 'data-k': 'notes', rows: 3,
        placeholder: 'One point per line…',
        onchange: (e) => { state.notes = e.target.value; renderAll(); }
      }, [state.notes || '']));
    }
  }

  /* ---------------------------------------------------------------------------
     5c. One-page export — horizontal bar chart
     Each individual is one thin horizontal bar (a mini-Gantt: virtual -> basic JQR ->
     resident course -> senior JQR, ending at an FTQ diamond), all on a shared time
     axis. Rows flow into 1-3 columns so the whole roster fills one US Letter
     LANDSCAPE page (fitExportPage() then scales the sheet to the page).
     --------------------------------------------------------------------------- */
  const EXPORT_DESIGN_W = 1360;   // inner content width in px (sheet adds padding); chosen for a ~landscape aspect

  function renderExport() {
    const sheet = $('#export-sheet');
    if (!sheet) return;
    sheet.innerHTML = '';
    if (!ui.export) return;

    const LABEL_W = 108, COL_GAP = 18;

    // Header
    const m = computeMetrics();
    const prev = prevMonthSnapshot();
    const fyTag = 'FY' + String(fq(TODAY).fy).slice(2);
    sheet.appendChild(el('div', { class: 'xs-head' }, [
      el('div', { class: 'xs-title', text: 'Training Pipeline — Roster Timeline' }),
      el('div', { class: 'xs-meta', text: 'As of ' + fmtLong(TODAY) })
    ]));

    // Top metrics — the same readiness tiles as the dashboard (with month-over-month deltas)
    const kTile = (value, of, label, deltaEl) => {
      const t = el('div', { class: 'xs-kpi' });
      const v = el('div', { class: 'xs-kv' }, [String(value)]);
      if (of != null) v.appendChild(el('span', { class: 'xs-kof', text: ' of ' + of }));
      t.appendChild(v);
      t.appendChild(el('div', { class: 'xs-kl', text: label }));
      if (deltaEl) t.appendChild(deltaEl);
      return t;
    };
    sheet.appendChild(el('div', { class: 'xs-kpis' }, [
      kTile(m.n, null, 'Individuals tracked'),
      kTile(m.projFtqByFy, m.n, 'Projected FTQ by end ' + fyTag),
      kTile(m.ftqReached, null, 'Fully trained (FTQ) to date', deltaBadge(prev ? m.ftqReached - prev.ftqReached : null, 'up', '', prev)),
      kTile(m.avgBasicDays, null, 'Avg Basic JQR (days)', deltaBadge(prev ? m.avgBasicDays - prev.avgBasicDays : null, 'down', 'd', prev))
    ]));

    const legItem = (cls, label) => el('span', { class: 'xs-leg' }, [el('i', { class: 'xs-sw ' + cls }), label]);
    sheet.appendChild(el('div', { class: 'xs-legend' }, [
      legItem('virtual', 'Virtual course'), legItem('basic', 'Basic JQR'),
      legItem('course', 'Resident course'), legItem('senior', 'Senior JQR'),
      el('span', { class: 'xs-leg' }, [el('i', { class: 'xs-sw diamond ftq' }), 'FTQ']),
      el('span', { class: 'xs-leg' }, [el('i', { class: 'xs-sw diamond nopath' }), 'No course path'])
    ]));

    if (!plans.length) { sheet.appendChild(el('div', { class: 'xs-empty', text: 'No individuals to show.' })); return; }

    // Shared time axis across all columns.
    let hs = TODAY, he = addDays(TODAY, 150);
    plans.forEach(pl => { hs = minIso(hs, pl.vStart); he = maxIso(he, pl.ftq || pl.seniorEnd || pl.fmq); he = maxIso(he, pl.vEnd); });
    const sd = parse(hs); sd.setUTCDate(1);
    const ed = parse(he); ed.setUTCDate(1); ed.setUTCMonth(ed.getUTCMonth() + 1);
    const H = { start: iso(sd), end: iso(ed) };
    const totalDays = diff(H.start, H.end) || 1;

    // Sort by FTQ, split into columns.
    const far = '9999-12-31';
    const list = plans.slice().sort((a, b) => (a.ftq || far).localeCompare(b.ftq || far) || a.person.name.localeCompare(b.person.name));
    const n = list.length;
    const K = n <= 18 ? 1 : n <= 70 ? 2 : 3;
    const colW = Math.floor((EXPORT_DESIGN_W - (K - 1) * COL_GAP) / K);
    const laneW = colW - LABEL_W;
    const perCol = Math.ceil(n / K);
    // Row height scales to roughly fill a landscape page (taller rows when few people,
    // thin rows when many); bar thickness tracks it. Bounded for legibility.
    let rowH = Math.max(16, Math.min(64, Math.round(910 / perCol)));
    const BAR_H = Math.max(8, Math.min(20, Math.round(rowH * 0.42)));
    const x = (d) => Math.max(0, Math.min(laneW, (diff(H.start, d) / totalDays) * laneW));

    const cols = el('div', { class: 'xs-cols', style: 'gap:' + COL_GAP + 'px' });
    for (let c = 0; c < K; c++) {
      const slice = list.slice(c * perCol, (c + 1) * perCol);
      if (!slice.length) continue;
      const col = el('div', { class: 'xs-col', style: 'width:' + colW + 'px' });

      // Axis: fiscal-quarter labels across the lane.
      const axis = el('div', { class: 'xs-axis', style: 'margin-left:' + LABEL_W + 'px;width:' + laneW + 'px' });
      for (let f = fq(H.start); fqStart(f.fy, f.q) < H.end; f = fqNext(f)) {
        axis.appendChild(el('div', { class: 'xs-tick', style: 'left:' + x(maxIso(fqStart(f.fy, f.q), H.start)) + 'px', text: 'Q' + f.q + (f.q === 1 ? " '" + String(f.fy).slice(2) : '') }));
      }
      col.appendChild(axis);

      // Body: quarter gridlines + today line behind the rows.
      const body = el('div', { class: 'xs-body' });
      const grid = el('div', { class: 'xs-grid-ov', style: 'left:' + LABEL_W + 'px;width:' + laneW + 'px' });
      for (let f = fq(H.start); fqStart(f.fy, f.q) < H.end; f = fqNext(f)) {
        grid.appendChild(el('div', { class: 'xs-gl' + (f.q === 1 ? ' fy' : ''), style: 'left:' + x(maxIso(fqStart(f.fy, f.q), H.start)) + 'px' }));
      }
      if (TODAY >= H.start && TODAY < H.end) grid.appendChild(el('div', { class: 'xs-today', style: 'left:' + x(TODAY) + 'px' }));
      body.appendChild(grid);

      slice.forEach(pl => body.appendChild(exportRow(pl, x, laneW, LABEL_W, rowH, BAR_H)));
      col.appendChild(body);
      cols.appendChild(col);
    }
    sheet.appendChild(cols);
    sheet.appendChild(el('div', { class: 'xs-foot', text: 'Each bar is one individual’s pipeline to FTQ · sorted by FTQ · ' + n + ' of ' + MAX_PEOPLE + ' tracked' }));
  }

  // One person as a horizontal bar: label on the left, phase segments + FTQ marker on a lane.
  function exportRow(pl, x, laneW, labelW, rowH, barH) {
    const p = pl.person;
    const row = el('div', { class: 'xs-row', style: 'height:' + rowH + 'px', title: p.name + ' — FTQ ' + (pl.ftq ? fmtLong(pl.ftq) : 'no course path') });
    row.appendChild(el('div', { class: 'xs-rl', style: 'width:' + labelW + 'px' }, [
      el('span', { class: 'chip ' + p.roleId, text: pl.role.short || pl.role.name }),
      el('span', { class: 'xs-rn', text: p.name || '(unnamed)' })
    ]));
    const lane = el('div', { class: 'xs-rlane', style: 'width:' + laneW + 'px' });
    const top = Math.round((rowH - barH) / 2);
    const seg = (cls, a, b) => el('div', { class: 'xs-seg ' + cls, style: 'left:' + x(a) + 'px;width:' + Math.max(2, x(b) - x(a)) + 'px;top:' + top + 'px;height:' + barH + 'px' });
    lane.appendChild(seg('virtual', pl.vStart, pl.vEnd));
    pl.basicSegs.forEach(s => lane.appendChild(seg('basic', s.start, s.end)));
    pl.seniorSegs.forEach(s => lane.appendChild(seg('senior', s.start, s.end)));
    pl.blocks.forEach(bl => lane.appendChild(seg('course', bl.start, bl.end)));   // drawn last -> sits on top
    const mk = Math.round(barH * 0.9);
    if (pl.ftq) lane.appendChild(el('div', { class: 'xs-mk ftq', style: 'left:' + (x(pl.ftq) - mk / 2) + 'px;top:' + (top + (barH - mk) / 2) + 'px;width:' + mk + 'px;height:' + mk + 'px' }));
    else lane.appendChild(el('div', { class: 'xs-mk nopath', style: 'left:' + (x(pl.fmq) - mk / 2) + 'px;top:' + (top + (barH - mk) / 2) + 'px;width:' + mk + 'px;height:' + mk + 'px' }));
    row.appendChild(lane);
    return row;
  }

  // One summary row. `kind` is 'fmq' or 'ftq' and drives the cell colour.
  // `total` is the row total; `denom` is group size (shown as "of N" when they differ).
  function numRow(label, kind, now, perQ, qs, total, denom) {
    const tr = el('tr', { class: kind });
    tr.appendChild(el('td', { class: 'label', html: '<span class="tag ' + kind + '"></span>' + escapeHtml(label) }));
    const cell = (v, extraClass) => el('td', { class: 'num' + (v === 0 ? ' zero' : ' hit') + (extraClass ? ' ' + extraClass : ''), text: v === 0 ? '·' : String(v) });
    tr.appendChild(cell(now, 'first'));
    perQ.forEach((v, idx) => tr.appendChild(cell(v, (idx === 0 || qs[idx - 1].fy !== qs[idx].fy ? 'first' : '') + (idx === 0 ? ' cur' : ''))));
    const td = el('td', { class: 'num total-cell first', text: String(total) });
    if (total !== denom) td.appendChild(el('span', { class: 'of', text: ' of ' + denom }));
    tr.appendChild(td);
    return tr;
  }

  function renderLegend() {
    $('#legend').innerHTML =
      '<span><i style="background:var(--virtual)"></i>Virtual course</span>' +
      '<span><i style="background:var(--basic)"></i>Basic JQR</span>' +
      '<span><i style="background:var(--senior)"></i>Senior JQR</span>' +
      '<span><i style="background:var(--course)"></i>Resident course block</span>' +
      '<span><i class="diamond" style="background:var(--fmq)"></i>FMQ</span>' +
      '<span><i class="diamond" style="background:var(--ftq)"></i>FTQ</span>' +
      '<span><i style="background:var(--today);width:3px"></i>Today</span>';
  }

  /* ---------------------------------------------------------------------------
     6. Timeline grid
     Layout: .grid (width = timeline px + left column)
               .thead   sticky top: quarter labels + month labels
               .rows    one .row per person (+ an .editor-row under the open one)
     Horizontal position of a date = diff(horizonStart, date) * pxPerDay.
     --------------------------------------------------------------------------- */

  // Time window to draw: starts at the first of LAST month (history before that is
  // not useful for a projection brief; earlier bars are clipped at the left edge),
  // ends at the latest FTQ + ~2 months, at least a year out, snapped to whole months.
  function horizon() {
    const start = addDays(TODAY, -31);
    let end = addDays(TODAY, 365);
    for (const pl of plans) {
      end = maxIso(end, pl.ftq || pl.fmq);
      end = maxIso(end, pl.vEnd);
    }
    end = addDays(end, 60);
    const s = parse(start); s.setUTCDate(1);
    const e = parse(end); e.setUTCDate(1); e.setUTCMonth(e.getUTCMonth() + 1);
    return { start: iso(s), end: iso(e) };
  }

  // Pixels per day. 'fit' divides the space right of the sticky left column by the
  // number of days in the horizon (floored at 1.4 so bars never become slivers;
  // below that the timeline scrolls horizontally).
  function pxPerDay(H, scroller) {
    if (!ui.export && ui.zoom !== 'fit') return Number(ui.zoom);   // export always fits horizontally (no page scroll)
    const leftW = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--left-w')) || 400;
    const avail = scroller.clientWidth - leftW - 2;
    return Math.max(ui.export ? 1 : 2.5, avail / diff(H.start, H.end));
  }

  function renderTimeline() {
    const scroller = $('#scroller');
    const prevScroll = { l: scroller.scrollLeft, t: scroller.scrollTop };   // keep position across re-renders
    scroller.innerHTML = '';

    const list = visiblePlans();
    const H = horizon();
    const px = pxPerDay(H, scroller);
    const width = diff(H.start, H.end) * px;
    const x = (d) => diff(H.start, d) * px;                    // left edge of a day
    const w = (a, b) => Math.max((diff(a, b) + 1) * px, 3);    // width of an inclusive date range

    const grid = el('div', { class: 'grid' });

    // ---- header ----
    const thead = el('div', { class: 'thead' });
    thead.appendChild(el('div', { class: 'thead-left' }, [
      el('div', { class: 'c-name', text: 'Individual' }),
      el('div', { class: 'c-jqr', text: 'JQR basic / senior' }),
      el('div', { class: 'c-date', text: 'FMQ' }),
      el('div', { class: 'c-date', text: 'FTQ' })
    ]));
    const lane = el('div', { class: 'thead-lane', style: 'width:' + width + 'px' });

    // quarter labels (top line) — also remembered as background bands for the rows
    const bands = [];
    const curKey = fqKey(fq(TODAY));
    let f = fq(H.start);
    while (fqStart(f.fy, f.q) < H.end) {
      const qs = maxIso(fqStart(f.fy, f.q), H.start), qe = minIso(fqEnd(f.fy, f.q), addDays(H.end, -1));
      const left = x(qs), wd = (diff(qs, qe) + 1) * px;
      lane.appendChild(el('div', { class: 'qh' + (fqKey(f) === curKey ? ' cur' : ''), style: 'left:' + left + 'px;width:' + wd + 'px', text: fqLabel(f) }));
      bands.push({ left, wd, alt: f.q % 2 === 0, fy: f.q === 1 });
      f = fqNext(f);
    }
    // month labels (second line); single letters when zoomed out
    const monthXs = [];   // month starts, reused as faint gridlines behind the rows
    let m = parse(H.start);
    while (iso(m) < H.end) {
      monthXs.push(x(iso(m)));
      const ms = iso(m); const n = new Date(m); n.setUTCMonth(n.getUTCMonth() + 1);
      const me = addDays(iso(n), -1);
      const monthW = (diff(ms, me) + 1) * px;
      const yr = (m.getUTCMonth() === 0 || ms === H.start) ? " '" + String(m.getUTCFullYear()).slice(2) : '';
      const label = monthW >= 46 ? MONTHS[m.getUTCMonth()] + yr : monthW >= 26 ? MONTHS[m.getUTCMonth()] : MONTHS[m.getUTCMonth()][0];
      lane.appendChild(el('div', { class: 'mh' + (m.getUTCMonth() === 0 ? ' dec' : ''), style: 'left:' + x(ms) + 'px;width:' + ((diff(ms, me) + 1) * px) + 'px', text: label }));
      m = n;
    }
    if (TODAY >= H.start && TODAY < H.end) lane.appendChild(el('div', { class: 'today-tag', style: 'left:' + (x(TODAY) + px / 2) + 'px', text: 'Today' }));
    thead.appendChild(lane);
    grid.appendChild(thead);

    // ---- rows ----
    const rows = el('div', { class: 'rows' });
    const bg = el('div', { class: 'grid-bg', style: 'width:' + width + 'px' });   // shared background: bands + today line
    bands.forEach(b => bg.appendChild(el('div', { class: 'band' + (b.alt ? ' alt' : ''), style: 'left:' + b.left + 'px;width:' + b.wd + 'px' })));
    monthXs.forEach(mx => bg.appendChild(el('div', { class: 'month-line', style: 'left:' + mx + 'px' })));
    bands.forEach(b => {
      bg.appendChild(el('div', { class: 'band-line' + (b.fy ? ' fy' : ''), style: 'left:' + b.left + 'px' }));   // darker line at each new FY
    });
    if (TODAY >= H.start && TODAY < H.end) bg.appendChild(el('div', { class: 'today-line', style: 'left:' + (x(TODAY) + px / 2 - 1) + 'px' }));
    rows.appendChild(bg);

    if (!list.length) rows.appendChild(el('div', { class: 'empty', text: state.people.length ? 'No individuals match this filter.' : 'No individuals yet. Use "Add individual" to start.' }));

    list.forEach((pl, i) => rows.appendChild(renderRow(pl, x, w, width, px, i)));
    grid.appendChild(rows);
    scroller.appendChild(grid);
    sizeEditor();
    scroller.scrollLeft = prevScroll.l; scroller.scrollTop = prevScroll.t;
  }

  // courseLocations: "Fort Eisenhower, GA / Fort Meade, MD" (timeline caption).
  // courseSummary:   "Course 1 · starts 13 Oct 26" (left column, caption tooltip).
  function courseLocations(pl) {
    return [...new Set(pl.blocks.map(b => b.location).filter(Boolean))].join(' / ');
  }
  function courseSummary(pl) {
    if (!pl.track) return 'No course cohort available';
    return pl.track.name + ' · starts ' + fmt(pl.blocks[0].start);   // locations are shown on the timeline caption
  }

  // One person: sticky left cells + timeline lane (+ editor if open).
  function renderRow(pl, x, w, width, px, idx) {
    const p = pl.person;
    const frag = document.createDocumentFragment();
    const row = el('div', {
      class: 'row' + (idx % 2 ? ' alt' : '') + (ui.openId === p.id ? ' open' : ''),
      onclick: () => { if (ui.present || ui.export) return; ui.openId = ui.openId === p.id ? null : p.id; renderAll(); }
    });

    // ---- left cells ----
    const left = el('div', { class: 'row-left' });
    // Name cell: line 1 = role chip + name (+ warning), line 2 = assigned course, cohort start, location(s).
    const nameCell = el('div', { class: 'c-name' });
    const line1 = el('div', { class: 'l1' });
    line1.appendChild(el('span', { class: 'chip ' + p.roleId, text: pl.role.short || pl.role.name }));
    line1.appendChild(el('span', { class: 'nm', text: p.name || '(unnamed)', title: p.name }));
    if (pl.warnings.length) line1.appendChild(el('span', { class: 'warn-dot', text: '!', title: pl.warnings.join('\n') }));
    nameCell.appendChild(line1);
    nameCell.appendChild(el('div', { class: 'l2' + (pl.track ? '' : ' na'), text: courseSummary(pl) }));
    left.appendChild(nameCell);

    // JQR cell: two thin progress bars with the percentages
    const jqr = el('div', { class: 'c-jqr', title: 'Basic JQR ' + p.basicPct + '% complete · ' + pl.basicDays + '-day duration\nSenior JQR ' + p.seniorPct + '% complete · ' + pl.seniorDays + '-day duration\n(% complete is progress only and does not change the projected dates)' });
    jqr.appendChild(el('div', { class: 'pct' }, [el('i', { class: 'bar basic' }, el('b', { style: 'width:' + clamp(p.basicPct, 0, 100) + '%' })), el('span', { text: p.basicPct + '%' })]));
    jqr.appendChild(el('div', { class: 'pct' }, [el('i', { class: 'bar senior' }, el('b', { style: 'width:' + clamp(p.seniorPct, 0, 100) + '%' })), el('span', { text: p.seniorPct + '%' })]));
    left.appendChild(jqr);

    left.appendChild(el('div', { class: 'c-date', text: fmt(pl.fmq), title: 'Basic qualified (FMQ)' }));
    left.appendChild(el('div', { class: 'c-date ftq' + (pl.ftq ? '' : ' na'), text: pl.ftq ? fmt(pl.ftq) : 'no cohort', title: pl.ftq ? 'Fully trained (FTQ)' : pl.warnings.join('\n') }));
    row.appendChild(left);

    // ---- lane ----
    const ln = el('div', { class: 'lane', style: 'width:' + width + 'px' });
    // seg(): one bar. Label only drawn if the bar is wide enough to hold text.
    const seg = (cls, a, b, label, title) => {
      const s = el('div', { class: 'seg ' + cls + (b < TODAY ? ' past' : ''), style: 'left:' + x(a) + 'px;width:' + w(a, b) + 'px', title });
      const text = typeof label === 'string' ? label : (label ? label.textContent : '');
      // ~8px per character at 14px semibold, plus padding
      if (text && w(a, b) >= text.length * 8 + 20) s.appendChild(typeof label === 'string' ? document.createTextNode(label) : label);
      return s;
    };
    ln.appendChild(seg('virtual', pl.vStart, pl.vEnd, pl.role.virtual.name,
      pl.role.virtual.name + '\n' + fmtLong(pl.vStart) + ' – ' + fmtLong(pl.vEnd) + (p.virtualEnd ? '\n(predicted end set manually)' : '')));
    pl.basicSegs.forEach((s, i) => ln.appendChild(seg('basic', s.start, s.end, i === 0 ? 'Basic JQR' : '',
      'Basic JQR: ' + pl.basicDays + '-day duration (' + p.basicPct + '% complete)\n' + fmtLong(s.start) + ' – ' + fmtLong(s.end))));
    pl.seniorSegs.forEach((s, i) => ln.appendChild(seg('senior', s.start, s.end, i === 0 ? 'Senior JQR' : '',
      'Senior JQR: ' + pl.seniorDays + '-day duration (' + p.seniorPct + '% complete)\n' + fmtLong(s.start) + ' – ' + fmtLong(s.end))));
    // Caption above the course: spans first block start to last block end, clipped to that width.
    if (pl.blocks.length) {
      const cs = pl.blocks[0].start, ce = pl.blocks[pl.blocks.length - 1].end;
      const locs = courseLocations(pl);
      ln.appendChild(el('div', { class: 'course-cap', style: 'left:' + x(cs) + 'px;min-width:' + w(cs, ce) + 'px', title: courseSummary(pl) },
        [pl.track.name, locs ? el('span', { class: 'loc', text: locs }) : null]));
    }
    pl.blocks.forEach((b, i) => {
      if (i > 0) {   // dashed connector between blocks of the same course
        const gapLeft = x(pl.blocks[i - 1].end) + px;
        ln.appendChild(el('div', { class: 'gap', style: 'left:' + gapLeft + 'px;width:' + Math.max(x(b.start) - gapLeft, 0) + 'px' }));
      }
      const name = pl.track.blocks[i] || 'Block ' + (i + 1);
      const label = name;
      ln.appendChild(seg('course b' + (i % 2), b.start, b.end, label,
        pl.track.name + ' — ' + name + '\n' + fmtLong(b.start) + ' – ' + fmtLong(b.end) + (b.location ? '\n' + b.location : '')));
    });
    if (!pl.ftq) ln.appendChild(el('div', { class: 'nocourse', style: 'left:' + (x(pl.fmq) + px + 16) + 'px', text: 'No course cohort available after ' + fmt(pl.vEnd) }));

    // Milestones: a diamond at the END of the FMQ / FTQ day, plus a dated flag under the bar.
    // The FMQ flag hangs to the LEFT of its diamond and the FTQ flag to the RIGHT, so the
    // two can never overlap (FTQ is always on or after FMQ).
    const fmqX = x(pl.fmq) + px;
    ln.appendChild(el('div', { class: 'mark fmq', style: 'left:' + fmqX + 'px', title: 'FMQ ' + fmtLong(pl.fmq) }));
    ln.appendChild(el('div', { class: 'flag fmq', style: 'right:' + (width - fmqX) + 'px', text: 'FMQ ' + fmt(pl.fmq) }));
    if (pl.ftq) {
      const ftqX = x(pl.ftq) + px;
      ln.appendChild(el('div', { class: 'mark ftq', style: 'left:' + ftqX + 'px', title: 'FTQ ' + fmtLong(pl.ftq) }));
      const flip = ftqX + 200 > width;   // not enough room to the right: hang the flag to the left instead
      ln.appendChild(el('div', { class: 'flag ftq' + (flip ? ' flip' : ''), style: flip ? 'right:' + (width - ftqX) + 'px' : 'left:' + ftqX + 'px' },
        ['FTQ ' + fmt(pl.ftq), el('span', { class: 'q', text: fqLabel(fq(pl.ftq)) })]));
    }
    row.appendChild(ln);
    frag.appendChild(row);

    if (ui.openId === p.id) frag.appendChild(renderEditor(pl));
    return frag;
  }

  // The editor is position:sticky inside a horizontally scrolling container, so it
  // needs an explicit width equal to the visible viewport of the scroller.
  function sizeEditor() {
    const scroller = $('#scroller'), ed = scroller.querySelector('.editor');
    if (ed) ed.style.width = scroller.clientWidth + 'px';
  }

  /* ---------------------------------------------------------------------------
     7. Row editor
     Every input writes straight into the person object via setP() and then
     re-renders. Inputs use the `change` event (fires on blur / Enter), not
     `input`, so the page does not re-render on every keystroke.
     --------------------------------------------------------------------------- */
  function renderEditor(pl) {
    const p = pl.person, r = pl.role;
    const wrap = el('div', { class: 'editor-row', onclick: (e) => e.stopPropagation() });   // don't toggle the row
    const ed = el('div', { class: 'editor' });
    const field = (label, input, cls) => el('div', { class: 'field' + (cls ? ' ' + cls : '') }, [el('label', { text: label }), input]);
    const setP = (patch) => { Object.assign(p, patch); renderAll(); };
    const intOrNull = (v) => v === '' ? null : Math.max(0, parseInt(v, 10) || 0);

    ed.appendChild(field('Name', el('input', { type: 'text', value: p.name, 'data-k': p.id + '-name', onchange: (e) => setP({ name: e.target.value.trim() }) })));

    // Changing role resets everything role-specific.
    const roleSel = el('select', { 'data-k': p.id + '-role', onchange: (e) => {
      const nr = role(e.target.value);
      setP({ roleId: nr.id, trackId: 'auto', iterationId: 'auto', virtualStart: nextCohort(nr, TODAY), virtualEnd: null, basicDaysTotal: null, seniorDaysTotal: null });
    } });
    state.roles.forEach(rr => roleSel.appendChild(el('option', { value: rr.id, text: rr.name, selected: rr.id === p.roleId })));
    ed.appendChild(field('Work role', roleSel));

    // Virtual course: cohort picker (sets the start) + free-form start + predicted end.
    const cohorts = (r.virtual.cohortStarts || []).slice().sort();
    const vSel = el('select', { 'data-k': p.id + '-vco', onchange: (e) => { if (e.target.value) setP({ virtualStart: e.target.value, virtualEnd: null }); } });
    if (!cohorts.includes(pl.vStart)) vSel.appendChild(el('option', { value: '', text: 'Custom date (' + fmt(pl.vStart) + ')', selected: true }));
    cohorts.forEach(d => vSel.appendChild(el('option', { value: d, text: fmt(d) + (d < TODAY ? ' (started)' : ''), selected: d === pl.vStart })));
    ed.appendChild(field(r.virtual.name + ' cohort', vSel));
    ed.appendChild(field(r.virtual.name + ' start', el('input', { type: 'date', value: pl.vStart, 'data-k': p.id + '-vs', onchange: (e) => { if (e.target.value) setP({ virtualStart: e.target.value }); } })));
    ed.appendChild(field('Predicted ' + r.virtual.name.toLowerCase() + ' end', el('div', { class: 'inline' }, [
      el('input', { type: 'date', value: pl.vEnd, 'data-k': p.id + '-ve', onchange: (e) => { if (e.target.value) setP({ virtualEnd: e.target.value }); } }),
      p.virtualEnd
        ? el('button', { class: 'link', type: 'button', text: 'use default', title: 'Reset to ' + r.virtual.defaultDays + ' days after start', onclick: () => setP({ virtualEnd: null }) })
        : el('span', { class: 'hint', text: 'default' })
    ])));

    // Senior course option
    const tSel = el('select', { 'data-k': p.id + '-track', onchange: (e) => setP({ trackId: e.target.value, iterationId: 'auto' }) });
    tSel.appendChild(el('option', { value: 'auto', text: 'Earliest FTQ (auto)', selected: p.trackId === 'auto' }));
    r.tracks.forEach(t => tSel.appendChild(el('option', { value: t.id, text: t.name, selected: t.id === p.trackId })));
    ed.appendChild(field('Senior course', tSel));

    // Cohort — option values are "trackId|iterationId" so picking one also sets the track.
    const iSel = el('select', { 'data-k': p.id + '-it', onchange: (e) => {
      const v = e.target.value;
      if (v === 'auto') setP({ iterationId: 'auto' });
      else { const [tid, iid] = v.split('|'); setP({ trackId: tid, iterationId: iid }); }
    } });
    const autoLabel = p.iterationId === 'auto' && pl.iteration
      ? 'Auto — ' + pl.track.name + ' ' + fmt(pl.blocks[0].start) + ' – ' + fmt(pl.courseEnd)
      : 'Earliest available (auto)';
    iSel.appendChild(el('option', { value: 'auto', text: autoLabel, selected: p.iterationId === 'auto' }));
    const tracksForList = p.trackId === 'auto' ? r.tracks : r.tracks.filter(t => t.id === p.trackId);
    tracksForList.forEach(t => {
      const grp = el('optgroup', { label: t.name });
      const sorted = t.iterations.slice().sort((a, b) => (a.blocks[0] ? a.blocks[0].start : '').localeCompare(b.blocks[0] ? b.blocks[0].start : ''));
      sorted.forEach(it => {
        const b = it.blocks.slice().sort((a, c) => a.start.localeCompare(c.start));
        if (!b.length) return;
        const locs = [...new Set(b.map(x => x.location).filter(Boolean))].join(' / ');
        const flag = b[0].start < TODAY ? '  (past)' : b[0].start <= pl.vEnd ? '  (before virtual end)' : '';
        grp.appendChild(el('option', {
          value: t.id + '|' + it.id,
          selected: it.id === p.iterationId,
          text: fmt(b[0].start) + ' – ' + fmt(b[b.length - 1].end) + (locs ? '  ' + locs : '') + flag
        }));
      });
      iSel.appendChild(grp);
    });
    ed.appendChild(field('Course cohort', iSel, 'wide'));

    // JQR progress: % complete, plus an optional override of the full-JQR duration.
    const pctInput = (key) => el('input', { type: 'number', min: 0, max: 100, step: 1, value: p[key], 'data-k': p.id + '-' + key,
      onchange: (e) => setP({ [key]: clamp(parseInt(e.target.value, 10) || 0, 0, 100) }) });
    const totalInput = (key, def) => el('input', { type: 'number', min: 0, step: 1, value: p[key] == null ? '' : p[key], placeholder: 'default ' + def, 'data-k': p.id + '-' + key,
      onchange: (e) => setP({ [key]: intOrNull(e.target.value) }) });
    ed.appendChild(field('Basic JQR duration (days) — drives estimate', totalInput('basicDaysTotal', r.basicDays)));
    ed.appendChild(field('Basic JQR % complete (progress only)', pctInput('basicPct')));
    ed.appendChild(field('Senior JQR duration (days) — drives estimate', totalInput('seniorDaysTotal', r.seniorDays)));
    ed.appendChild(field('Senior JQR % complete (progress only)', pctInput('seniorPct')));

    // Computed outcome line
    const out = el('div', { class: 'outcome' });
    const kv = (k, v) => out.appendChild(el('span', {}, [el('span', { class: 'k', text: k }), el('b', { text: v })]));
    kv('Virtual end', fmtLong(pl.vEnd));
    kv('Basic JQR', pl.basicDays + ' days (' + p.basicPct + '% done)');
    kv('FMQ', fmtLong(pl.fmq) + ' (' + fqLabel(fq(pl.fmq)) + ')');
    kv('Course', pl.track ? pl.track.name + ', ends ' + fmtLong(pl.courseEnd) : 'none');
    kv('Senior JQR', pl.seniorDays + ' days (' + p.seniorPct + '% done)' + (pl.seniorDays > 0 ? ', ends ' + fmtLong(pl.seniorEnd) : ''));
    kv('FTQ', pl.ftq ? fmtLong(pl.ftq) + ' (' + fqLabel(fq(pl.ftq)) + ')' : 'not reachable');
    pl.warnings.forEach(wn => out.appendChild(el('span', { class: 'warn', text: wn })));
    ed.appendChild(out);

    const actions = el('div', { class: 'actions' });
    actions.appendChild(el('button', { class: 'btn btn-danger btn-sm', type: 'button', text: 'Remove', onclick: () => {
      if (!confirm('Remove ' + p.name + '?')) return;
      state.people = state.people.filter(q => q.id !== p.id); ui.openId = null; renderAll();
    } }));
    actions.appendChild(el('button', { class: 'btn btn-sm', type: 'button', text: 'Duplicate', onclick: () => {
      if (state.people.length >= MAX_PEOPLE) return alert('Limit of ' + MAX_PEOPLE + ' individuals reached.');
      const c = clone(p); c.id = uid('p'); c.name = p.name + ' (copy)';
      state.people.splice(state.people.indexOf(p) + 1, 0, c); ui.openId = c.id; renderAll();
    } }));
    actions.appendChild(el('button', { class: 'btn btn-sm', type: 'button', text: 'Done', onclick: () => { ui.openId = null; renderAll(); } }));
    ed.appendChild(actions);
    wrap.appendChild(ed);
    return wrap;
  }

  /* ---------------------------------------------------------------------------
     8. Course catalog dialog (<dialog id="catalog">)
     Edits mutate state.roles directly and re-render everything, so timelines
     update live behind the dialog.
     --------------------------------------------------------------------------- */
  function renderCatalog() {
    const dlg = $('#catalog');
    const prevScroll = dlg.scrollTop;
    dlg.innerHTML = '';
    dlg.appendChild(el('div', { class: 'dlg-head' }, [
      el('div', {}, [el('h2', { text: 'Course catalog' }), el('p', { class: 'hint', text: 'Changes apply immediately to every timeline and are saved in this browser.' })]),
      el('button', { class: 'btn', type: 'button', text: 'Close', onclick: closeCatalog })
    ]));
    const body = el('div', { class: 'dlg-body' });

    // global assumptions
    const settings = el('div', { class: 'fieldset' });
    settings.appendChild(el('h3', { text: 'Assumptions' }));
    settings.appendChild(el('div', { class: 'frow' }, [
      el('label', {}, [el('input', { type: 'checkbox', checked: !!state.settings.pauseDuringCourse, onchange: (e) => { state.settings.pauseDuringCourse = e.target.checked; renderAll(); } }), 'JQR work pauses while attending a resident course']),
      el('span', { class: 'hint', text: 'JQR work starts the day after the virtual course ends (or today, if later). Senior JQR starts after basic JQR. Each JQR runs for its set duration in calendar days; the per-individual % complete is progress only and does not change the projected dates.' })
    ]));
    body.appendChild(settings);

    state.roles.forEach((r, ri) => body.appendChild(renderRoleEditor(r, ri)));
    body.appendChild(el('div', { style: 'padding:12px 0' }, el('button', { class: 'btn btn-sm', type: 'button', text: 'Add work role', onclick: () => {
      const n = state.roles.length + 1;
      state.roles.push({ id: uid('wr'), name: 'Work Role ' + n, short: 'WR' + n, virtual: { name: 'Virtual course', defaultDays: 60, cohortStarts: [nextMonthFirst(TODAY)] }, basicDays: 90, seniorDays: 120, tracks: [] });
      renderAll();
    } })));
    dlg.appendChild(body);
    dlg.scrollTop = prevScroll;
  }

  function nextMonthFirst(d) { const x = parse(d); x.setUTCDate(1); x.setUTCMonth(x.getUTCMonth() + 1); return iso(x); }

  function renderRoleEditor(r, ri) {
    const box = el('div', { class: 'role-block' });
    const title = el('div', { class: 'role-title' });
    title.appendChild(el('input', { class: 'txt', type: 'text', value: r.name, 'data-k': r.id + '-name', title: 'Work role name', onchange: (e) => { r.name = e.target.value.trim() || r.name; renderAll(); } }));
    title.appendChild(el('label', { class: 'hint' }, ['Short label ', el('input', { type: 'text', value: r.short || '', style: 'width:70px', 'data-k': r.id + '-short', onchange: (e) => { r.short = e.target.value.trim(); renderAll(); } })]));
    title.appendChild(el('label', { class: 'hint' }, ['Full basic JQR (days) ', el('input', { type: 'number', min: 0, value: r.basicDays, 'data-k': r.id + '-bd', onchange: (e) => { r.basicDays = Math.max(0, parseInt(e.target.value, 10) || 0); renderAll(); } })]));
    title.appendChild(el('label', { class: 'hint' }, ['Full senior JQR (days) ', el('input', { type: 'number', min: 0, value: r.seniorDays, 'data-k': r.id + '-sd', onchange: (e) => { r.seniorDays = Math.max(0, parseInt(e.target.value, 10) || 0); renderAll(); } })]));
    if (state.roles.length > 1) title.appendChild(el('button', { class: 'btn btn-danger btn-sm', type: 'button', text: 'Remove role', onclick: () => {
      const used = state.people.filter(p => p.roleId === r.id).length;
      if (!confirm('Remove ' + r.name + '?' + (used ? ' ' + used + ' individual(s) will be moved to another role.' : ''))) return;
      state.roles.splice(ri, 1);
      state.people.forEach(p => { if (p.roleId === r.id) { p.roleId = state.roles[0].id; p.trackId = 'auto'; p.iterationId = 'auto'; } });
      renderAll();
    } }));
    box.appendChild(title);

    // virtual course block
    const v = el('div', { class: 'fieldset' });
    v.appendChild(el('h3', { text: 'Self-paced virtual course' }));
    v.appendChild(el('div', { class: 'frow' }, [
      el('label', {}, ['Name ', el('input', { class: 'txt', type: 'text', value: r.virtual.name, 'data-k': r.id + '-vn', onchange: (e) => { r.virtual.name = e.target.value.trim() || 'Virtual course'; renderAll(); } })]),
      el('label', {}, ['Default duration (days) ', el('input', { type: 'number', min: 1, value: r.virtual.defaultDays, 'data-k': r.id + '-vd', onchange: (e) => { r.virtual.defaultDays = Math.max(1, parseInt(e.target.value, 10) || 1); renderAll(); } })])
    ]));
    v.appendChild(el('div', { class: 'hint', style: 'margin-bottom:6px', text: 'Cohort start dates' }));
    const cd = el('div', { class: 'cohort-dates' });
    r.virtual.cohortStarts = (r.virtual.cohortStarts || []).slice().sort();
    r.virtual.cohortStarts.forEach((d, i) => cd.appendChild(el('span', { class: 'cd' }, [
      el('input', { type: 'date', value: d, 'data-k': r.id + '-co' + i, onchange: (e) => { if (e.target.value) { r.virtual.cohortStarts[i] = e.target.value; renderAll(); } } }),
      el('button', { type: 'button', title: 'Remove', text: '×', onclick: () => { r.virtual.cohortStarts.splice(i, 1); renderAll(); } })
    ])));
    cd.appendChild(el('button', { class: 'btn btn-sm', type: 'button', text: 'Add cohort', onclick: () => {
      const last = r.virtual.cohortStarts[r.virtual.cohortStarts.length - 1] || TODAY;
      r.virtual.cohortStarts.push(addDays(last, 28)); renderAll();
    } }));
    v.appendChild(cd);
    box.appendChild(v);

    r.tracks.forEach((t, ti) => box.appendChild(renderTrackEditor(r, t, ti)));
    box.appendChild(el('button', { class: 'btn btn-sm', type: 'button', text: 'Add senior course option', onclick: () => {
      r.tracks.push({ id: uid('c'), name: 'Course ' + (r.tracks.length + 1), blocks: ['Block 1'], iterations: [] }); renderAll();
    } }));
    return box;
  }

  // One course option: block names + a table of iterations (one row each, one
  // start/end/location triple per block).
  function renderTrackEditor(r, t, ti) {
    const box = el('div', { class: 'track' });
    const tt = el('div', { class: 'track-title' });
    tt.appendChild(el('input', { class: 'txt', type: 'text', value: t.name, 'data-k': t.id + '-name', style: 'font-weight:600', onchange: (e) => { t.name = e.target.value.trim() || t.name; renderAll(); } }));
    tt.appendChild(el('span', { class: 'hint', text: t.blocks.length + (t.blocks.length === 1 ? ' block' : ' blocks') + ', ' + t.iterations.length + (t.iterations.length === 1 ? ' iteration' : ' iterations') }));
    tt.appendChild(el('button', { class: 'btn btn-sm', type: 'button', text: 'Add block', onclick: () => {
      t.blocks.push('Block ' + (t.blocks.length + 1));
      // give every existing iteration a placeholder block 3 weeks after its last one
      t.iterations.forEach(it => { const last = it.blocks[it.blocks.length - 1]; const s = last ? addDays(last.end, 21) : TODAY; it.blocks.push({ start: s, end: addDays(s, 13), location: last ? last.location : '' }); });
      renderAll();
    } }));
    if (t.blocks.length > 1) tt.appendChild(el('button', { class: 'btn btn-quiet btn-sm', type: 'button', text: 'Remove last block', onclick: () => { t.blocks.pop(); t.iterations.forEach(it => it.blocks.pop()); renderAll(); } }));
    tt.appendChild(el('button', { class: 'btn btn-danger btn-sm', type: 'button', text: 'Remove course', onclick: () => {
      if (!confirm('Remove ' + t.name + ' and all of its iterations?')) return;
      r.tracks.splice(ti, 1);
      state.people.forEach(p => { if (p.trackId === t.id) { p.trackId = 'auto'; p.iterationId = 'auto'; } });
      renderAll();
    } }));
    box.appendChild(tt);

    const bn = el('div', { class: 'blocks-names' });
    bn.appendChild(el('span', { text: 'Block names' }));
    t.blocks.forEach((b, bi) => bn.appendChild(el('input', { type: 'text', value: b, 'data-k': t.id + '-b' + bi, onchange: (e) => { t.blocks[bi] = e.target.value.trim() || b; renderAll(); } })));
    box.appendChild(bn);

    const table = el('table', { class: 'it-table' });
    const thr = el('tr');
    thr.appendChild(el('th', { text: '#' }));
    t.blocks.forEach(b => { thr.appendChild(el('th', { class: 'blk', text: b + ' start' })); thr.appendChild(el('th', { text: 'end' })); thr.appendChild(el('th', { text: 'location' })); });
    thr.appendChild(el('th'));
    table.appendChild(el('thead', {}, thr));
    const tb = el('tbody');
    t.iterations.sort((a, b) => (a.blocks[0] ? a.blocks[0].start : '').localeCompare(b.blocks[0] ? b.blocks[0].start : ''));
    t.iterations.forEach((it, ii) => {
      // keep every iteration in sync with the block count
      while (it.blocks.length < t.blocks.length) { const last = it.blocks[it.blocks.length - 1]; const s = last ? addDays(last.end, 21) : TODAY; it.blocks.push({ start: s, end: addDays(s, 13), location: '' }); }
      const used = state.people.filter(p => p.iterationId === it.id).length;
      const tr = el('tr');
      tr.appendChild(el('td', { class: 'idx', text: String(ii + 1) + (used ? ' (' + used + ' assigned)' : '') }));
      it.blocks.slice(0, t.blocks.length).forEach((b, bi) => {
        const prev = bi > 0 ? it.blocks[bi - 1] : null;
        const bad = b.end < b.start || (prev && b.start <= prev.end);   // red outline for impossible dates
        tr.appendChild(el('td', { class: 'blk' }, el('input', { type: 'date', value: b.start, class: bad ? 'bad' : '', 'data-k': it.id + '-s' + bi, onchange: (e) => { if (e.target.value) { b.start = e.target.value; renderAll(); } } })));
        tr.appendChild(el('td', {}, el('input', { type: 'date', value: b.end, class: bad ? 'bad' : '', 'data-k': it.id + '-e' + bi, onchange: (e) => { if (e.target.value) { b.end = e.target.value; renderAll(); } } })));
        tr.appendChild(el('td', {}, el('input', { type: 'text', class: 'loc', value: b.location || '', placeholder: 'Location', 'data-k': it.id + '-l' + bi, onchange: (e) => { b.location = e.target.value.trim(); renderAll(); } })));
      });
      tr.appendChild(el('td', {}, el('button', { class: 'del', type: 'button', title: 'Remove iteration', text: '×', onclick: () => {
        if (used && !confirm('This iteration is assigned to ' + used + ' individual(s). Remove it? They will fall back to the earliest available cohort.')) return;
        t.iterations.splice(ii, 1);
        state.people.forEach(p => { if (p.iterationId === it.id) p.iterationId = 'auto'; });
        renderAll();
      } })));
      tb.appendChild(tr);
    });
    table.appendChild(tb);
    box.appendChild(el('div', { class: 'it-wrap' }, table));
    box.appendChild(el('div', { style: 'margin-top:8px' }, el('button', { class: 'btn btn-sm', type: 'button', text: 'Add iteration', onclick: () => {
      // new iteration = last one shifted ~a quarter, or a blank template if none exist
      const last = t.iterations[t.iterations.length - 1];
      let blocks;
      if (last) blocks = last.blocks.map(b => ({ start: addDays(b.start, 91), end: addDays(b.end, 91), location: b.location }));
      else { let s = nextMonthFirst(TODAY); blocks = t.blocks.map(() => { const b = { start: s, end: addDays(s, 13), location: '' }; s = addDays(s, 35); return b; }); }
      t.iterations.push({ id: uid(t.id + '-'), blocks }); renderAll();
    } })));
    return box;
  }

  function openCatalog() { ui.catalogOpen = true; renderCatalog(); $('#catalog').showModal(); }
  function closeCatalog() { ui.catalogOpen = false; $('#catalog').close(); }

  /* ---------------------------------------------------------------------------
     8b. Durable file persistence  (optional, zero-dependency)
     Binds the dashboard to ONE JSON file via the browser's File System Access API
     so state survives across sessions and devices (put the file on a shared drive)
     and matches the copy you upload to the bucket. localStorage is always the
     immediate cache, so the app runs out of the box with nothing connected; the
     file is the durable layer that also lets the monthly snapshots accumulate.
     Everything here degrades silently when the API is unavailable (Firefox/Safari,
     or file:// in some browsers) — Export/Import + localStorage still work.
     --------------------------------------------------------------------------- */
  const FS_OK = ('showSaveFilePicker' in window) && ('showOpenFilePicker' in window);
  let fileHandle = null;      // bound FileSystemFileHandle, or null
  let fileState = 'off';      // 'off' | 'synced' | 'reconnect'
  let writing = false, writeTimer = 0;

  // Minimal IndexedDB key/value store, used only to remember the file handle
  // across reloads. No library — the native API.
  function idb(mode, fn) {
    return new Promise((resolve, reject) => {
      const open = indexedDB.open('trainingPipeline', 1);
      open.onupgradeneeded = () => open.result.createObjectStore('kv');
      open.onerror = () => reject(open.error);
      open.onsuccess = () => {
        const db = open.result, tx = db.transaction('kv', mode), st = tx.objectStore('kv');
        let out; try { const r = fn(st); tx.oncomplete = () => { db.close(); resolve(r ? r.result : out); }; }
        catch (e) { db.close(); reject(e); }
        tx.onerror = () => { db.close(); reject(tx.error); };
      };
    });
  }
  const idbGet = (k) => idb('readonly', s => s.get(k)).catch(() => null);
  const idbSet = (k, v) => idb('readwrite', s => s.put(v, k)).catch(() => {});
  const idbDel = (k) => idb('readwrite', s => s.delete(k)).catch(() => {});

  async function perm(handle, write) {
    if (!handle || !handle.queryPermission) return 'granted';
    const opts = { mode: write ? 'readwrite' : 'read' };
    if ((await handle.queryPermission(opts)) === 'granted') return 'granted';
    try { return await handle.requestPermission(opts); } catch (e) { return 'denied'; }  // request needs a user gesture
  }

  async function readHandle(handle) {
    const f = await handle.getFile();
    const s = JSON.parse(await f.text());
    if (!Array.isArray(s.roles) || !Array.isArray(s.people)) throw new Error('not a valid data file');
    return s;
  }

  async function writeFile() {
    if (!fileHandle) return;
    if (writing) { scheduleFileWrite(); return; }   // a write is in flight; retry with the latest state after it
    writing = true;
    try {
      if ((await perm(fileHandle, true)) !== 'granted') { setFileState('reconnect'); return; }
      const w = await fileHandle.createWritable();
      await w.write(JSON.stringify(state, null, 2));
      await w.close();
      setFileState('synced');
    } catch (e) { console.warn('data-file write failed', e); }
    finally { writing = false; }
  }
  function scheduleFileWrite() {
    if (!fileHandle) return;
    clearTimeout(writeTimer);
    writeTimer = setTimeout(writeFile, 400);   // debounce bursts of edits into one write
  }

  function setFileState(s) {
    fileState = s;
    const btn = $('#btn-file'); if (!btn) return;
    btn.hidden = !FS_OK;
    btn.classList.toggle('file-on', s === 'synced');
    btn.classList.toggle('file-warn', s === 'reconnect');
    btn.textContent = s === 'synced' ? '● Saving to ' + (fileHandle ? fileHandle.name : 'file')
      : s === 'reconnect' ? 'Reconnect data file'
      : 'Connect data file';
    btn.title = s === 'synced' ? 'Every change is saved to this file. Click to disconnect.'
      : s === 'reconnect' ? 'Click to re-grant access to the connected file.'
      : 'Bind this dashboard to a JSON file so changes are saved durably (and shareable).';
  }

  // One button drives connect / reconnect / disconnect depending on current state.
  async function fileButtonClick() {
    if (fileState === 'synced') {
      if (confirm('Stop saving to this file?\n\nThe dashboard keeps its data (also cached in this browser); it just stops auto-saving to the file.')) {
        fileHandle = null; await idbDel('handle'); setFileState('off');
      }
      return;
    }
    if (fileState === 'reconnect' && fileHandle) {
      if ((await perm(fileHandle, true)) !== 'granted') return;
      try { state = migrate(await readHandle(fileHandle)); ui.openId = null; renderAll(); }
      catch (e) { writeFile(); }
      setFileState('synced');
      return;
    }
    // Off -> pick/create the file. Picking an existing file offers to load it.
    try {
      const h = await window.showSaveFilePicker({
        suggestedName: 'training-pipeline-data.json',
        types: [{ description: 'Training pipeline data', accept: { 'application/json': ['.json'] } }]
      });
      if ((await perm(h, true)) !== 'granted') return;
      fileHandle = h;
      let existing = null;
      try { existing = await readHandle(h); } catch (e) { existing = null; }
      if (existing && Array.isArray(existing.people) && (existing.people.length || Object.keys(existing.snapshots || {}).length)) {
        if (confirm('This file already contains pipeline data.\n\nOK — load it into the dashboard (replaces what is on screen now)\nCancel — keep the current data and overwrite the file')) {
          state = migrate(existing); ui.openId = null;
        }
      }
      await idbSet('handle', h);
      setFileState('synced');
      renderAll();          // persists current state to the file via save()
    } catch (e) { /* user cancelled the picker */ }
  }

  // On startup: if we remember a handle, reconnect (silently if the browser kept
  // permission, otherwise show the "Reconnect" state for a one-click re-grant).
  async function initFilePersistence() {
    if (!FS_OK) { const b = $('#btn-file'); if (b) b.hidden = true; return; }
    setFileState('off');
    try {
      const h = await idbGet('handle');
      if (!h) return;
      fileHandle = h;
      if ((await h.queryPermission({ mode: 'readwrite' })) === 'granted') {
        try { state = migrate(await readHandle(h)); ui.openId = null; renderAll(); setFileState('synced'); return; }
        catch (e) { /* fall through */ }
      }
      setFileState('reconnect');
    } catch (e) { setFileState('off'); }
  }

  /* ---------------------------------------------------------------------------
     9. Import / export — the whole state as a JSON file
     --------------------------------------------------------------------------- */
  function exportJson() {
    const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'training-pipeline-' + TODAY + '.json';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }
  function importJson(file) {
    const rd = new FileReader();
    rd.onload = () => {
      try {
        const s = JSON.parse(rd.result);
        if (!Array.isArray(s.roles) || !Array.isArray(s.people)) throw new Error('file has no roles/people arrays');
        state = migrate(s); ui.openId = null; renderAll();
      } catch (e) { alert('Could not import: ' + e.message); }
    };
    rd.readAsText(file);
  }

  /* ---------------------------------------------------------------------------
     10. Event wiring and first render
     --------------------------------------------------------------------------- */
  $('#btn-add').addEventListener('click', () => {
    if (state.people.length >= MAX_PEOPLE) return alert('Limit of ' + MAX_PEOPLE + ' individuals reached.');
    const r = state.roles[0];
    const p = { id: uid('p'), name: 'New individual', roleId: r.id, trackId: 'auto', iterationId: 'auto',
      virtualStart: nextCohort(r, TODAY), virtualEnd: null, basicPct: 0, seniorPct: 0, basicDaysTotal: null, seniorDaysTotal: null };
    state.people.push(p); ui.openId = p.id;
    renderAll();
    const row = $('#scroller .row.open'); if (row) row.scrollIntoView({ block: 'center' });
    const nm = document.querySelector('[data-k="' + p.id + '-name"]'); if (nm) { nm.focus(); nm.select(); }
  });
  $('#btn-file').addEventListener('click', fileButtonClick);
  $('#btn-catalog').addEventListener('click', openCatalog);
  $('#catalog').addEventListener('close', () => { ui.catalogOpen = false; });   // Esc key
  $('#btn-export').addEventListener('click', exportJson);
  $('#btn-import').addEventListener('click', () => $('#file-import').click());
  $('#file-import').addEventListener('change', (e) => { if (e.target.files[0]) importJson(e.target.files[0]); e.target.value = ''; });
  $('#btn-reset').addEventListener('click', () => {
    if (confirm('Replace everything with the sample data from data.js?')) { state = migrate(clone(window.DEFAULT_DATA)); ui.openId = null; renderAll(); }
  });
  $('#zoom').addEventListener('change', (e) => { ui.zoom = e.target.value; renderTimeline(); });
  // Row density is pure CSS (geometry variables on <body>), so it needs no re-render —
  // except 'fit' zoom, which depends on layout, so we nudge the timeline in that case.
  function setDensity(d) {
    ui.density = d;
    document.body.classList.remove('density-wide', 'density-standard', 'density-compact', 'density-dense');
    document.body.classList.add('density-' + d);
    if (ui.zoom === 'fit') renderTimeline();   // (density does not affect the export bar chart)
  }
  $('#density').addEventListener('change', (e) => setDensity(e.target.value));
  // Present: toggles body.present (see styles.css) and closes any open editor.
  function setPresent(on) {
    if (on && ui.export) setExport(false);   // the two full-screen modes are mutually exclusive
    ui.present = on; ui.openId = null;
    document.body.classList.toggle('present', on);
    $('#btn-present').textContent = on ? 'Exit briefing view' : 'Briefing view';
    renderAll();
  }
  $('#btn-present').addEventListener('click', () => setPresent(!ui.present));

  // Export view: the whole dashboard scaled to one US Letter LANDSCAPE page.
  function setExport(on) {
    if (on && ui.present) setPresent(false);
    ui.export = on; ui.openId = null;
    document.body.classList.toggle('export', on);
    $('#export-sheet').hidden = !on;
    $('#btn-export-view').textContent = on ? 'Exit export view' : 'Export view';
    if (!on) $('#export-sheet').style.zoom = '';
    renderAll();
  }
  $('#btn-export-view').addEventListener('click', () => setExport(!ui.export));
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape' || ui.catalogOpen) return;
    if (ui.export) setExport(false);
    else if (ui.present) setPresent(false);
  });
  // Print: the export view prints itself (one page); otherwise print uses briefing.
  let wasPresent = false;
  window.addEventListener('beforeprint', () => { if (ui.export) return; wasPresent = ui.present; if (!ui.present) setPresent(true); });
  window.addEventListener('afterprint', () => { if (!ui.export && !wasPresent) setPresent(false); });
  $('#sort').addEventListener('change', (e) => { ui.sort = e.target.value; renderTimeline(); });
  $('#filter-role').addEventListener('change', (e) => { ui.filter = e.target.value; renderTimeline(); });
  // Re-layout on resize: 'fit' zoom depends on the window width. Debounced to one frame.
  let resizeRaf = 0;
  window.addEventListener('resize', () => {
    cancelAnimationFrame(resizeRaf);
    resizeRaf = requestAnimationFrame(() => {
      if (ui.export) return;                 // export scales to a fixed page size, not the window
      if (ui.zoom === 'fit') renderTimeline();
      else sizeEditor();
    });
  });
  $('#sort').value = ui.sort;
  $('#density').value = ui.density;
  setDensity(ui.density);
  $('#subtitle').textContent = 'Projected basic (FMQ) and fully trained (FTQ) dates by individual and fiscal quarter, as of ' + fmtLong(TODAY);

  // Console access for debugging (see header comment).
  window.__pipeline = { get state() { return state; }, get plans() { return plans; }, schedule, renderAll, TODAY };

  renderAll();
  initFilePersistence();   // async; reconnects a previously bound data file if possible
})();
