===============================================================================
  TRAINING PIPELINE PROJECTION
  A single-page dashboard that projects when each individual will be basic-
  qualified (FMQ) and fully trained (FTQ), and rolls it up by fiscal quarter.
===============================================================================

No install, no internet, no accounts. It is four files in one folder and runs in
any modern browser.


-------------------------------------------------------------------------------
1. QUICK START
-------------------------------------------------------------------------------
  - Double-click  index.html  (or host the folder on any web server / bucket).
  - You will see sample data. Replace it with your own:
      * Click "Add individual" to add people, or click any row to edit one.
      * Click "Course catalog" to set up work roles, courses and cohort dates.
      * Click "Reset to sample" at any time to start over from the built-in data.
  - To keep your data safely, see section 7 (SAVING YOUR DATA).

  Best viewed in Chrome or Edge. It works in other browsers too, but the
  "Connect data file" saving option (section 7) is Chrome/Edge only.


-------------------------------------------------------------------------------
2. THE WORDS ON THE SCREEN
-------------------------------------------------------------------------------
  Work role        A job the pipeline produces (e.g. Work Role 1 / Work Role 2).
                   Each role has its own virtual course, JQRs and resident courses.
  Virtual course   The self-paced course each person starts in, by cohort date.
  Basic JQR        The basic qualification record (line items) a person works
                   through after the virtual course.
  FMQ              "Basic qualified" = virtual course + basic JQR complete.
  Senior JQR       The senior qualification record, worked after the basic JQR.
  Resident course  An in-person course (one or more blocks at a location).
  FTQ              "Fully trained" = FMQ + senior JQR + senior resident course
                   complete. This is the end state the dashboard optimises for.

  Fiscal year (FY): starts 1 Oct.  Q1 Oct-Dec, Q2 Jan-Mar, Q3 Apr-Jun, Q4 Jul-Sep.


-------------------------------------------------------------------------------
3. WHAT YOU ARE LOOKING AT
-------------------------------------------------------------------------------
  TOP PANEL - "Fully trained (FTQ) by fiscal quarter"
     * Readiness tiles: headline numbers (see section 6).
     * Table: how many people reach FTQ in each fiscal quarter, per work role
       and overall. "Already" = before today; the current quarter counts only
       from today forward, so Already + the quarters add up to the Total.
     * Legend: what the colours and diamonds mean.
     * Notes: your own briefing points (see section 5).

  BOTTOM PANEL - "Individual timelines"
     One row per person. On the left: name, assigned course, JQR progress, and
     the projected FMQ and FTQ dates. On the right: a timeline showing the
     virtual course, basic JQR, senior JQR and resident-course blocks, with
     FMQ / FTQ marked. Click a row to edit that person.


-------------------------------------------------------------------------------
4. HOW THE DATES ARE PROJECTED
-------------------------------------------------------------------------------
  For each person, in order:
    1. Virtual course runs from its cohort start to its predicted end.
    2. Basic JQR starts the day after the virtual course ends (or today, if
       that is later) and runs for the basic JQR duration (in calendar days).
       When it finishes -> FMQ.
    3. Senior JQR starts the day after the basic JQR ends and runs for the
       senior JQR duration.
    4. Senior resident course: by default the tool tries every cohort of every
       course option for the role that starts after the virtual course, and
       picks the one that reaches FTQ soonest. You can pin a specific course
       and cohort per person instead.
    5. FTQ = whichever is later: the senior course ends, or the senior JQR ends.
    6. JQR work pauses while a person is away at a resident course (this can be
       turned off in Course catalog > Assumptions).

  IMPORTANT - JQR duration vs. % complete:
     The projected dates depend ONLY on the JQR DURATION (in days). The
     "% complete" value is a progress indicator (the small bars in the left
     column) and does NOT change any dates. To make an estimate shorter or
     longer, edit the JQR duration - not the percentage.


-------------------------------------------------------------------------------
5. EDITING
-------------------------------------------------------------------------------
  PEOPLE: click a row to open its editor. You can set the name, work role,
  virtual cohort/start/predicted-end, which senior course and cohort to use
  (or leave on "auto" for the earliest FTQ), and the JQR durations and
  % complete. Buttons: Remove, Duplicate, Done. Up to 100 people.

  COURSES / ROLES: click "Course catalog". There you can add or edit work
  roles, virtual-course cohort dates, and each resident course's blocks and
  iterations (start / end / location). Changes apply to every timeline live.

  NOTES: the Notes box (top panel) is free text, one point per line. It shows
  as an editable box normally and as slide-style bullet points in Briefing
  view and when printed.


-------------------------------------------------------------------------------
6. THE READINESS TILES (and why saving matters)
-------------------------------------------------------------------------------
  Individuals tracked        Everyone on the roster (registered for the virtual
                             course or further along).
  Projected FTQ by end FYxx  How many are projected fully trained by 30 Sep of
                             the current fiscal year, on the current plan.
  Fully trained (FTQ) to date Count already past their FTQ date, with the change
                             since last month.
  Avg Basic JQR (days)       Average Basic JQR duration across the roster, with
                             the change since last month (down = faster = green).

  MONTHLY SNAPSHOTS: once a month the dashboard quietly records these numbers
  into the saved data. Opening it in a new month freezes last month's figures
  and starts the new month. The two "change since last month" figures compare
  this month to the most recent earlier month on record. Until a prior month
  exists they read "baseline set this month". This history only survives if your
  data is being saved - which is why the saving options below matter.


-------------------------------------------------------------------------------
7. SAVING YOUR DATA
-------------------------------------------------------------------------------
  There are two layers; you don't have to choose - they work together.

  (a) AUTOMATIC (always on). Your data is cached in the browser (localStorage)
      the moment you change anything. It survives closing the tab and reopening
      on the same computer and browser. It is NOT shared with other people or
      devices, and it is separate from the sample in data.js.

  (b) DATA FILE (recommended, Chrome/Edge). Click "Connect data file" and pick
      (or create) one JSON file. From then on every change auto-saves to that
      file, and reopening reloads from it. Put that file on a shared drive
      (OneDrive / Google Drive / a network share) and the whole team works off
      one source of truth - no server needed. The button turns green while it is
      saving; if it says "Reconnect data file" after reopening, click it once to
      re-grant access. This uses a built-in browser feature - no add-ons.

  EXPORT / IMPORT: "Export" saves everything (roster, courses, notes, snapshots)
  to a JSON file you can back up or hand to someone. "Import" loads one back in.
  "Reset to sample" discards your data and reloads data.js.


-------------------------------------------------------------------------------
8. VIEWS (for reading and briefing)
-------------------------------------------------------------------------------
  Zoom      Horizontal scale of the timeline. "Standard" ~ 120px/month;
            "Fit to screen" squeezes the whole span into the window.
  Rows      Vertical density - how many people fit and how much detail shows:
              Wide      few large rows, biggest text, full detail
              Standard  the default
              Compact   shorter rows; FMQ/FTQ flags dropped (dates stay on left)
              Dense     most rows; just name + FMQ + FTQ + bars, for a whole-
                        roster glance
  Sort      FTQ date (default), order added, FMQ date, name, or work role.
  Show      Filter to one work role.
  Briefing view   Hides all editing controls and makes the page read-only, with
                  the notes as slide bullets. Press Esc to exit.
  Export view     A one-page horizontal bar chart of the whole roster on ONE US
                  Letter LANDSCAPE page, with the readiness metric tiles across the
                  top. Each individual is a single pipeline bar
                  (virtual course -> basic JQR -> resident course -> senior JQR,
                  ending at an FTQ diamond) on a shared fiscal-quarter axis with a
                  "today" line. Bars are sorted by FTQ and flow into 1-3 columns so
                  the whole roster fills the page - one wide column for small teams,
                  up to three columns at the 100-person cap. Press Esc to exit.
  Print / PDF     Ctrl+P prints one landscape US Letter page - the Export view
                  prints the one-page bar chart; otherwise it prints the timeline in
                  the briefing layout. Choose "Save as PDF" to produce a file.


-------------------------------------------------------------------------------
9. HOSTING ON A CLOUD BUCKET
-------------------------------------------------------------------------------
  The whole thing is static. Upload these files to the bucket and serve them:
      index.html   styles.css   app.js   data.js   (README optional)
  No build step, no dependencies.

  A plain bucket cannot run server code, so "always-synced, shared" storage
  comes from the DATA FILE option in section 7 (one JSON file on a shared
  drive). If you later want a true central multi-writer store with no shared-
  drive step, that is the one piece that needs a small backing service (e.g. a
  tiny key-value API) - a separate add-on, not required to run the dashboard.


-------------------------------------------------------------------------------
10. TROUBLESHOOTING
-------------------------------------------------------------------------------
  Page looks blank or broken after a bad import:
      Click "Reset to sample", or clear this site's storage in the browser.
  "Connect data file" button is missing:
      Your browser doesn't support it (use Chrome or Edge over https/localhost).
      localStorage + Export/Import still work.
  Numbers look off / someone can't reach FTQ:
      The note under the table lists anyone with no available course cohort
      after their virtual course. Add an iteration in Course catalog, or pin a
      different course/cohort in that person's editor.
  Text looks different on another computer:
      The UI uses Arial Nova Cond (ships with Windows) and falls back to
      Arial Narrow / Arial elsewhere - layout is fine either way.


-------------------------------------------------------------------------------
11. FOR MAINTAINERS - THE FILES
-------------------------------------------------------------------------------
  index.html   The shell. Empty containers that app.js fills.
  styles.css   All styling. Colours and ROW-DENSITY sizes are variables at the
               top (:root) so the look retunes in one place.
  data.js      The default roster and course catalog, loaded only when there is
               no saved data (or after "Reset to sample"). Safe to hand-edit;
               the format is documented in comments at the top of the file.
  app.js       All logic and rendering, organised into numbered sections with a
               map at the top of the file. For debugging, open the browser
               console: window.__pipeline exposes the live state and plans.
